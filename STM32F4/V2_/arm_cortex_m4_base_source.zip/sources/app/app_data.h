#ifndef __APP_DATA_H__
#define __APP_DATA_H__
#include <stdint.h>

#include "../sys/sys_boot.h"

#include "app.h"

/******************************************************************************
* IF Type
*******************************************************************************/
/** RF24 interface for modules
 * IF_TYPE_RF24_GW using to transfer data to gateway.
 * IF_TYPE_RF24_AC using to transfer data to air_condition module.
*/
#define IF_TYPE_RF24_MIN					(0)
#define IF_TYPE_RF24_GW						(0)
#define IF_TYPE_RF24_AC						(1)
#define IF_TYPE_RF24_MAX					(99)

/** APP interface, communication via socket interface
 *
 */
#define IF_TYPE_APP_MIN						(100)
#define IF_TYPE_APP_GW						(100)
#define IF_TYPE_APP_GI						(101)
#define IF_TYPE_APP_MAX						(119)

/** UART interface
 *
 */
#define IF_TYPE_UART_GW_MIN					(120)
#define IF_TYPE_UART_GW						(120)
#define IF_TYPE_UART_AC						(121)
#define IF_TYPE_UART_GW_MAX					(140)


#define RF24_ENCRYPT_DECRYPT_KEY_SIZE		16
extern uint8_t rf24_encrypt_decrypt_key[];

typedef struct {
	uint8_t is_power_on_reset;
} boot_app_share_data_t;

typedef struct {
	char firmware_version[10];						/* firmware version */
	char hardware_version[10];						/* hardware version */

	uint8_t aircond_time_switch_interval;			/* range time (hour) saved in epprom */
	uint8_t aircond_amount;							/* total air conditioner */
	uint8_t aircond_mode;							/* auto/manual */
	uint8_t aircond_active_temp_high;				/* *C */
	uint8_t aircond_active_temp_low;				/* *C */
	uint8_t aircond_backup_temp_high;				/* *C */
	uint8_t aircond_backup_temp_low;				/* *C */
	uint8_t fan_backup_temp_high;					/* *C */
	uint8_t fan_backup_temp_low;					/* *C */
	uint16_t aircond_milestone[4];	/* mA */
	uint8_t aircond_total_active;					/* total air conditioner active */     //<------------- edit from firmware ver 2.2
} __AK_PACKETED sl_app_settings_t;

typedef struct {
	sl_app_settings_t app_setting;

	uint16_t	aircond_time_switch_counter;		/* time will increase when hr change*/

	uint8_t		calib_temp_1_val;					/* *C */
	uint8_t		calib_temp_1_opt;					/* + / - */
	uint8_t		calib_temp_2_val;					/* *C */
	uint8_t		calib_temp_2_opt;					/* + / - */
	uint8_t		calib_hum_val;						/* %RH */
	uint8_t		calib_hum_opt;						/* + / - */
} sl_local_settings_t;

#endif //__APP_DATA_H__
