#include "fsm.h"
#include "port.h"
#include "timer.h"
#include "message.h"

#include "ui_screen.h"
#include "app.h"
#include "app_dbg.h"
#include "app_flash.h"

#include "task_list.h"
#include "task_ui.h"
#include "task_sm.h"
//#include "task_sensor.h"
//#include "task_setting.h"
//#include "task_ctrl_pop.h"

#include "utils.h"
#include "xprintf.h"
#include "view_render.h"
#include "screen_manager.h"

#include "sys_dbg.h"
#include "sys_ctrl.h"

enum {
	SCR_TRAN_SETTING_NONE,
	SCR_TRAN_SETTING_MAIN
};

fsm_t fsm_ui;
scr_mng_t screen_ui;

button_t btn_mode;
button_t btn_up;
button_t btn_down;

static uint8_t item_setting = 0;
static uint8_t item_setting_cursor = 0;
static uint8_t item_setting_flag = 0;

void btn_mode_callback(void* b) {
	button_t* me_b = (button_t*)b;
	switch (me_b->state) {
	case BUTTON_SW_STATE_RELEASE:
		break;

	case BUTTON_SW_STATE_SHORT_HOLD_PRESS: {
	}
		break;

	case BUTTON_SW_STATE_SHORT_RELEASE_PRESS: {
		button_disable(&btn_mode);
	}
		break;

	case BUTTON_SW_STATE_LONG_PRESS: {
	}
		break;

	default:
		break;
	}
}

void btn_up_callback(void* b) {
	button_t* me_b = (button_t*)b;
	switch (me_b->state) {
	case BUTTON_SW_STATE_SHORT_RELEASE_PRESS: {
		button_disable(&btn_up);
	}
		break;

	case BUTTON_SW_STATE_SHORT_HOLD_PRESS: {
		button_disable(&btn_up);
	}
		break;

	case BUTTON_SW_STATE_LONG_PRESS: {
		button_disable(&btn_up);
	}
		break;

	default:
		break;
	}
}

void btn_down_callback(void* b) {
	button_t* me_b = (button_t*)b;
	switch (me_b->state) {
	case BUTTON_SW_STATE_SHORT_RELEASE_PRESS: {
		button_disable(&btn_down);
	}
		break;

	case BUTTON_SW_STATE_SHORT_HOLD_PRESS: {
		button_disable(&btn_up);
	}
		break;

	case BUTTON_SW_STATE_LONG_PRESS: {
		button_disable(&btn_down);
	}
		break;

	default:
		break;
	}
}

void btn_up_focus_taget(view_screen_t* view_screen, uint8_t end_item, uint8_t begin_item) {
	if (view_screen->focus_item >= begin_item) {
		view_screen->focus_item_before = view_screen->focus_item;
		view_screen->focus_item --;

		if (view_screen->focus_item == (begin_item - 1)) {
			view_screen->focus_item = end_item - 1;
		}

		view_screen->focus_item_after = view_screen->focus_item;
	}
}

void btn_down_focus_taget(view_screen_t* view_screen, uint8_t end_item, uint8_t begin_item) {
	if (view_screen->focus_item < end_item) {
		view_screen->focus_item_before = view_screen->focus_item;
		view_screen->focus_item ++;

		if (view_screen->focus_item == end_item) {
			view_screen->focus_item = begin_item;
		}

		view_screen->focus_item_after = view_screen->focus_item;
	}
}

void reset_scr_obj(view_screen_t* view_screen, uint8_t item) {
	view_screen->focus_item = item;
	view_screen->focus_item_after = item;
	view_screen->focus_item_before = item;
}

void reset_item_setting() {
	item_setting = 0;
	item_setting_cursor = 0;
}

/*****************************************************************************/
/* Task UI
 */
/*****************************************************************************/

void task_ui(ak_msg_t* msg) {
	fsm_dispatch(&fsm_ui, msg);
}

void ui_state_display_on(ak_msg_t* msg) {
	if (msg->sig == SL_UI_SCREEN_HOME_UPDATE) {
		if (ctrl_scr_main == scr_mng_get_current_screen()) {
			view_render_screen(&scr_main);
		}
	}
	else if (msg->sig == SL_UI_GOTO_HOME) {
		if (ctrl_scr_main != scr_mng_get_current_screen()) {
			reset_item_setting();

			/*reset parameter setting time*/
			reset_scr_obj(&scr_main_setting, 1);

			/*reset parameter setting time*/
			reset_scr_obj(&scr_time_setting, 1);

			((view_rectangle_t*) scr_time_setting.item[1])->border_width = 0;
			((view_rectangle_t*) scr_time_setting.item[2])->border_width = 0;

			/*reset parameter setting air */
			reset_scr_obj(&scr_air_setting, 1);
			reset_scr_obj(&scr_air_total_setting, 1);
			reset_scr_obj(&scr_air_timer_setting, 1);
			reset_scr_obj(&scr_air_temp_setting, 1);
			reset_scr_obj(&scr_air_temp_aircond_setting, 1);
			reset_scr_obj(&scr_air_temp_fan_setting, 1);

			((view_rectangle_t*) scr_air_total_setting.item[1])->border_width = 0;
			((view_rectangle_t*) scr_air_total_setting.item[2])->border_width = 0;

			((view_rectangle_t*) scr_air_timer_setting.item[1])->border_width = 0;

			((view_rectangle_t*) scr_air_temp_aircond_setting.item[1])->border_width = 0;
			((view_rectangle_t*) scr_air_temp_aircond_setting.item[2])->border_width = 0;
			((view_rectangle_t*) scr_air_temp_aircond_setting.item[3])->border_width = 0;
			((view_rectangle_t*) scr_air_temp_aircond_setting.item[4])->border_width = 0;

			((view_rectangle_t*) scr_air_temp_fan_setting.item[1])->border_width = 0;
			((view_rectangle_t*) scr_air_temp_fan_setting.item[2])->border_width = 0;

			/*reset parameter setting engineer */
			reset_scr_obj(&scr_engineer_setting, 1);
			reset_scr_obj(&scr_engineer_network_setting, 1);
			reset_scr_obj(&scr_engineer_change_mode, 1);
			reset_scr_obj(&scr_engineer_control_output_setting, 1);
			reset_scr_obj(&scr_engineer_control_aircond_setting, 1);
			reset_scr_obj(&scr_engineer_control_general_output_setting, 1);
			reset_scr_obj(&scr_engineer_calib_setting, 1);
			reset_scr_obj(&scr_engineer_calib_current_air_setting, 1);
			reset_scr_obj(&scr_engineer_calib_temp_hum_setting, 1);

			((view_rectangle_t*) scr_engineer_change_mode.item[1])->border_width = 0;

			((view_rectangle_t*) scr_engineer_control_aircond_setting.item[2])->border_width = 0;
			((view_rectangle_t*) scr_engineer_control_aircond_setting.item[3])->border_width = 0;
			((view_rectangle_t*) scr_engineer_control_aircond_setting.item[4])->border_width = 0;
			((view_rectangle_t*) scr_engineer_control_aircond_setting.item[5])->border_width = 0;

			((view_rectangle_t*) scr_engineer_control_general_output_setting.item[2])->border_width = 0;
			((view_rectangle_t*) scr_engineer_control_general_output_setting.item[3])->border_width = 0;
			((view_rectangle_t*) scr_engineer_control_general_output_setting.item[4])->border_width = 0;
			((view_rectangle_t*) scr_engineer_control_general_output_setting.item[5])->border_width = 0;

			((view_rectangle_t*) scr_engineer_network_setting.item[1])->border_width = 0;
			((view_rectangle_t*) scr_engineer_network_setting.item[2])->border_width = 0;
			((view_rectangle_t*) scr_engineer_network_setting.item[3])->border_width = 0;

			((view_rectangle_t*) scr_engineer_calib_current_air_setting.item[2])->border_width = 0;
			((view_rectangle_t*) scr_engineer_calib_current_air_setting.item[3])->border_width = 0;
			((view_rectangle_t*) scr_engineer_calib_current_air_setting.item[4])->border_width = 0;
			((view_rectangle_t*) scr_engineer_calib_current_air_setting.item[5])->border_width = 0;

			((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[1])->border_width = 0;
			((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[2])->border_width = 0;
			((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[3])->border_width = 0;
			((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[4])->border_width = 0;

			/*reset parameter setting default */
			reset_scr_obj(&scr_default_setting, 1);

			task_post_pure_msg(SL_TASK_SM_ID, SL_SM_UI_SETTING_END_REQ);

			SCREEN_TRAN(ctrl_scr_main, &scr_main);
		}

		timer_set(SL_TASK_UI_ID, SL_UI_DISPLAY_OFF, SL_UI_TIMER_DISPLAY_OFF_INTERVAL, TIMER_ONE_SHOT);
	}
	else {
		scr_mng_dispatch(msg);

		if (scr_mng_get_current_screen() != ctrl_scr_settings_firmware_update) {
			timer_set(SL_TASK_UI_ID, SL_UI_GOTO_HOME, SL_UI_TIMER_TIMEOUT_INTERVAL, TIMER_ONE_SHOT);
		}
	}
}

void ui_state_display_off(ak_msg_t* msg) {
	switch (msg->sig) {
	case SL_UI_SCREEN_HOME_UPDATE :
		view_render_screen(&scr_main);
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		view_render_display_on();
		task_post_pure_msg(SL_TASK_UI_ID, SL_UI_GOTO_HOME);
		FSM_TRAN(&fsm_ui, ui_state_display_on);
	}
		break;

	default:
		break;
	}
}

/*****************************************************************************/
/* MAIN screen
 */
/*****************************************************************************/
void switch_status_smoke_sensor(void) {
	if (alarm_sensors_flag.smoke_alarm == 0)
		alarm_sensors_flag.smoke_alarm = 1;
	else
		alarm_sensors_flag.smoke_alarm = 0;

	task_post_common_msg(SL_TASK_SETTING_ID, SL_SETTING_SET_ALARM_FLAG_REQ, (uint8_t*)&alarm_sensors_flag, sizeof(sl_alarm_flag_t));
}

void reset_status_smoke_sensor(void) {
	task_post_pure_msg(SL_TASK_CTRL_POP_ID, SL_RL_SMOKE_SENSOR_RESET_START_REQ);
}

void ctrl_scr_main(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY: {
		timer_set(SL_TASK_UI_ID, SL_UI_DISPLAY_OFF, SL_UI_TIMER_DISPLAY_OFF_INTERVAL, TIMER_ONE_SHOT);
	}
		break;

	case SL_UI_DISPLAY_OFF: {
		view_render_display_off();
		FSM_TRAN(&fsm_ui, ui_state_display_off);
	}
		break;

	case SL_UI_INITIAL: {
		APP_DBG("SL_UI_INITIAL\n");

		/* enable using button */
		button_enable(&btn_mode);
		button_enable(&btn_up);
		button_enable(&btn_down);

		view_render_init();
	}
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		APP_DBG("SL_SM_UI_SETTING_START_REQ\n");
		task_post_pure_msg(SL_TASK_SM_ID, SL_SM_UI_SETTING_START_REQ);
	}
		break;

	case SL_UI_BUTTON_UP_PRESS:
		SCREEN_TRAN(ctrl_scr_main_current_aircond, &scr_main_current_aircond);
		break;

	case SL_UI_BUTTON_UP_SHORT_HOLD:
		APP_DBG("SL_UI_BUTTON_UP_SHORT_HOLD\n");
		reset_status_smoke_sensor();
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		SCREEN_TRAN(ctrl_scr_main_app_setting, &scr_main_app_setting);
		break;

	case SL_UI_BUTTON_DOWN_SHORT_HOLD:
		APP_DBG("SL_UI_BUTTON_DOWN_SHORT_HOLD\n");
		switch_status_smoke_sensor();
		break;

	case SL_UI_SETTING_SM_BUSY:
		APP_DBG("SL_UI_SETTING_SM_BUSY\n");
		SCREEN_TRAN(ctrl_scr_settings_system_busy, &scr_system_busy);
		break;

	case SL_UI_SETTING_SM_OK:
		APP_DBG("SL_UI_SETTING_SM_OK\n");
		SCREEN_TRAN(ctrl_scr_main_setting, &scr_main_setting);
		break;

	case SL_UI_FIRMWARE_UPDATE_START:
		APP_DBG("SL_UI_FIRMWARE_UPDATE_START\n");
		SCREEN_TRAN(ctrl_scr_settings_firmware_update, &scr_firmware_update);
		break;

	default:
		break;
	}
}

void ctrl_scr_main_current_aircond(ak_msg_t* msg) {
	static uint8_t time_out = 0;

	switch (msg->sig) {
	case SCREEN_ENTRY :
		timer_set(SL_TASK_UI_ID, SL_UI_VIEW_CURRENT_UPDATE, SL_UI_TIMER_AUTO_VIEW_INTERVAL, TIMER_ONE_SHOT);
		break;

	case SL_UI_BUTTON_UP_PRESS: {
		SCREEN_TRAN(ctrl_scr_main_network_gateway, &scr_main_network_gateway);
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS: {
		SCREEN_TRAN(ctrl_scr_main, &scr_main);
	}
		break;

	case SL_UI_VIEW_CURRENT_UPDATE:
		if ((time_out++) * SL_UI_TIMER_AUTO_VIEW_INTERVAL >= SL_UI_TIMER_TIMEOUT_INTERVAL) {
			time_out = 0;

			task_post_pure_msg(SL_TASK_UI_ID, SL_UI_GOTO_HOME);
		}
		else {
			timer_set(SL_TASK_UI_ID, SL_UI_VIEW_CURRENT_UPDATE, SL_UI_TIMER_AUTO_VIEW_INTERVAL, TIMER_ONE_SHOT);
		}
		break;

	default:
		break;
	}
}

void ctrl_scr_main_app_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY:
		break;

	case SL_UI_BUTTON_UP_PRESS: {
		SCREEN_TRAN(ctrl_scr_main, &scr_main);
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS: {
		SCREEN_TRAN(ctrl_scr_main_network_gateway, &scr_main_network_gateway);
	}
		break;

	default:
		break;
	}
}

void ctrl_scr_main_network_gateway(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY:
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		/* get network gateway info */
		timer_remove_attr(SL_TASK_SETTING_ID, SL_SETTING_GET_MT_NETWORK_INFO_REQ);
		timer_remove_attr(SL_TASK_SETTING_ID, SL_SETTING_GET_MT_NETWORK_INFO_ERR_RES);

		task_post_pure_msg(SL_TASK_SETTING_ID, SL_SETTING_GET_MT_NETWORK_INFO_REQ);

		gw_network_info_flag = 2;
	}
		break;

	case SL_UI_BUTTON_UP_PRESS: {
		SCREEN_TRAN(ctrl_scr_main_app_setting, &scr_main_app_setting);
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS: {
		SCREEN_TRAN(ctrl_scr_main_current_aircond, &scr_main_current_aircond);
	}
		break;

	case SL_UI_VIEW_NETWORK_INFO_UPDATE: {
	}
		break;

	default:
		break;
	}
}

void ctrl_scr_settings_system_busy(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY:
		timer_set(SL_TASK_UI_ID, SL_UI_BUSY_GOTO_HOME, SL_UI_TIMER_AUTO_VIEW_INTERVAL, TIMER_ONE_SHOT);
		break;

	case SL_UI_BUSY_GOTO_HOME: {
		task_post_pure_msg(SL_TASK_UI_ID, SL_UI_GOTO_HOME);
	}
		break;

	default:
		break;
	}
}

void ctrl_scr_settings_firmware_update(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		timer_remove_attr(SL_TASK_UI_ID, SL_UI_GOTO_HOME);
		break;

	case SL_UI_FIRMWARE_GOTO_HOME: {
		APP_DBG("SL_UI_FIRMWARE_GOTO_HOME\n");
		SCREEN_TRAN(ctrl_scr_main, &scr_main);
	}
		break;

	case SL_UI_FIRMWARE_UPDATE_COMPLETE :{
		APP_DBG("SL_UI_FIRMWARE_UPDATE_COMPLETE\n");
		SCREEN_TRAN(ctrl_scr_main, &scr_main);
	}
		break;

	case SL_UI_FIRMWARE_UPDATE_ERROR :{
		APP_DBG("SL_UI_FIRMWARE_UPDATE_ERROR\n");
		SCREEN_TRAN(ctrl_scr_main, &scr_main);
	}
		break;

	case SL_UI_FIRMWARE_UPDATE_TIMEOUT : {
		APP_DBG("SL_UI_FIRMWARE_UPDATE_TIMEOUT\n");
		SCREEN_TRAN(ctrl_scr_main, &scr_main);
	}
		break;

	default:
		break;
	}
}

/*****************************************************************************/
/* MAIN SETTING screen
 */
/*****************************************************************************/
void ctrl_scr_main_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		switch (scr_main_setting.focus_item) {
		case 1:
			SCREEN_TRAN(ctrl_scr_time_setting, &scr_time_setting);
			break;

		case 2:
			SCREEN_TRAN(ctrl_scr_air_setting, &scr_air_setting);
			break;

		case 3:
			SCREEN_TRAN(ctrl_scr_engineer_setting, &scr_engineer_setting);
			break;

		case 4:
			SCREEN_TRAN(ctrl_scr_default_setting, &scr_default_setting);
			break;

		case 5: {
			scr_main_setting.focus_item = 1;
			scr_main_setting.focus_item_before = 1;
			scr_main_setting.focus_item_after = 1;

			task_post_pure_msg(SL_TASK_SM_ID, SL_SM_UI_SETTING_END_REQ);

			SCREEN_TRAN(ctrl_scr_main, &scr_main);
		}
			break;

		default:
			break;
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		btn_down_focus_taget(&scr_main_setting, NUMBER_SCREEN_ITEMS_MAX, 1);

		break;

	case SL_UI_BUTTON_UP_PRESS:
		btn_up_focus_taget(&scr_main_setting, NUMBER_SCREEN_ITEMS_MAX, 1);

		break;

	default:
		break;
	}
}

/*****************************************************************************/
/* TIME SETTING screen
 */
/*****************************************************************************/
void increase_real_time_hour(void) {
	setting_rtc_time.hours ++;

	if (setting_rtc_time.hours > 23) {
		setting_rtc_time.hours = 0;
	}
}

void decrease_real_time_hour(void) {
	setting_rtc_time.hours --;

	if (setting_rtc_time.hours == 255) {
		setting_rtc_time.hours = 23;
	}
}

void increase_real_time_min(void) {
	setting_rtc_time.minutes ++;

	if (setting_rtc_time.minutes > 59) {
		setting_rtc_time.minutes = 0;
	}
}

void decrease_real_time_min(void) {
	setting_rtc_time.minutes --;

	if (setting_rtc_time.minutes == 255) {
		setting_rtc_time.minutes = 59;
	}
}

void increase_real_time_date(void) {
	setting_rtc_time.day ++;

	if (setting_rtc_time.day > 31) {
		setting_rtc_time.day = 1;
	}
}

void decrease_real_time_date(void) {
	setting_rtc_time.day --;

	if (setting_rtc_time.day == 0) {
		setting_rtc_time.day = 31;
	}
}

void increase_real_time_mon(void) {
	setting_rtc_time.mon ++;

	if (setting_rtc_time.mon > 12) {
		setting_rtc_time.mon = 1;
	}
}

void decrease_real_time_mon(void) {
	setting_rtc_time.mon --;

	if (setting_rtc_time.mon == 0) {
		setting_rtc_time.mon = 12;
	}
}

void increase_real_time_year(void) {
	setting_rtc_time.year ++;

	if (setting_rtc_time.year >= 100) {
		setting_rtc_time.year = 0;
	}
}

void decrease_real_time_year(void) {
	setting_rtc_time.year --;

	if (setting_rtc_time.year == 255) {
		setting_rtc_time.year = 99;
	}
}

void setting_real_time_dmy(void) {
	if (setting_rtc_time.mon == 4 ||setting_rtc_time.mon == 6 || setting_rtc_time.mon == 9 ||setting_rtc_time.mon == 11) {
		if(setting_rtc_time.day == 31) {
			setting_rtc_time.day = 30;
		}
	}
	else if (setting_rtc_time.mon == 2 && setting_rtc_time.year % 4 == 0) {
		if(setting_rtc_time.day > 29) {
			setting_rtc_time.day = 29;
		}
	}
	else if (setting_rtc_time.mon == 2 && setting_rtc_time.year % 4 != 0) {
		if(setting_rtc_time.day > 28) {
			setting_rtc_time.day = 28;
		}
	}

	/*send msg to task setting*/
	task_post_pure_msg(SL_TASK_SETTING_ID, SL_SETTING_TIME_RTC_UPDATE_REQ);
}

void ctrl_scr_time_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		rtc_get_time(&rtc, &setting_rtc_time);
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		if (item_setting == 0 && (scr_time_setting.focus_item == 1 || scr_time_setting.focus_item == 2)) {
			item_setting = 1;
			scr_time_setting.focus_item_before = scr_time_setting.focus_item;
			scr_time_setting.focus_item_after = scr_time_setting.focus_item;

			((view_rectangle_t*) scr_time_setting.item[scr_time_setting.focus_item])->focus_cursor = 0;
			((view_rectangle_t*) scr_time_setting.item[scr_time_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1 ) {
			item_setting_cursor = item_setting_cursor + 4;

			if ((scr_time_setting.focus_item == 1 && item_setting_cursor > 4)||(scr_time_setting.focus_item == 2 && item_setting_cursor > 8)) {
				setting_real_time_dmy();

				reset_item_setting();
				((view_rectangle_t*) scr_time_setting.item[scr_time_setting.focus_item])->border_width = 0;
			}
			else {
				((view_rectangle_t*) scr_time_setting.item[scr_time_setting.focus_item])->focus_cursor = item_setting_cursor;
				((view_rectangle_t*) scr_time_setting.item[scr_time_setting.focus_item])->border_width = 1;
			}
		}
		else if (scr_time_setting.focus_item == 3) {
			reset_item_setting();

			scr_time_setting.focus_item = 1;
			scr_time_setting.focus_item_before = 1;
			scr_time_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_main_setting, &scr_main_setting);
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_time_setting, 4, 1);
		}
		else {
			if (scr_time_setting.focus_item == 1) {
				if (item_setting_cursor == 0) {
					decrease_real_time_hour();
				}
				else {
					decrease_real_time_min();
				}
			}
			else if (scr_time_setting.focus_item == 2){
				if (item_setting_cursor == 0) {
					decrease_real_time_date();
				}
				else if (item_setting_cursor == 4){
					decrease_real_time_mon();
				}
				else {
					decrease_real_time_year();
				}
			}
		}
		break;

	case SL_UI_BUTTON_UP_PRESS:
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_time_setting, 4, 1);
		}
		else {
			if (scr_time_setting.focus_item == 1) {
				if (item_setting_cursor == 0) {
					increase_real_time_hour();
				}
				else {
					increase_real_time_min();
				}
			}
			else if (scr_time_setting.focus_item == 2) {
				if (item_setting_cursor == 0) {
					increase_real_time_date();
				}
				else if (item_setting_cursor == 4) {
					increase_real_time_mon();
				}
				else {
					increase_real_time_year();
				}
			}
		}
		break;

	default:
		break;
	}

	if (setting_rtc_time.hours > 100 || setting_rtc_time.minutes > 100) {
		xsprintf(((view_rectangle_t*) scr_time_setting.item[1])->text,"       ");
	}
	if (setting_rtc_time.day > 100 || setting_rtc_time.mon > 100 || setting_rtc_time.year > 100) {
		xsprintf(((view_rectangle_t*) scr_time_setting.item[2])->text,"            ");
	}

	xsprintf(((view_rectangle_t*) scr_time_setting.item[1])->text,"%02d : %02d",setting_rtc_time.hours, setting_rtc_time.minutes);
	xsprintf(((view_rectangle_t*) scr_time_setting.item[2])->text,"%02d - %02d - %02d",setting_rtc_time.day, setting_rtc_time.mon, setting_rtc_time.year);
}

/*****************************************************************************/
/* AIR SETTING screen
 */
/*****************************************************************************/
void increase_total_aircond(void) {
	local_setting.app_setting.aircond_amount ++;

	if (local_setting.app_setting.aircond_amount > SL_TOTAL_AIRCOND) {
		local_setting.app_setting.aircond_amount = 1;
	}
}

void decrease_total_aircond(void) {
	local_setting.app_setting.aircond_amount --;

	if (local_setting.app_setting.aircond_amount == 0 || local_setting.app_setting.aircond_amount == 255) {
		local_setting.app_setting.aircond_amount = SL_TOTAL_AIRCOND;
	}
}

void increase_total_aircond_active(void) {
	local_setting.app_setting.aircond_total_active ++;

	if (local_setting.app_setting.aircond_total_active > local_setting.app_setting.aircond_amount - 1) {
		local_setting.app_setting.aircond_total_active = 1;
	}
}

void decrease_total_aircond_active(void) {
	local_setting.app_setting.aircond_total_active --;

	if (local_setting.app_setting.aircond_total_active == 0 || local_setting.app_setting.aircond_total_active == 255) {
		local_setting.app_setting.aircond_total_active = local_setting.app_setting.aircond_amount - 1;
	}
}

void check_value_total_air() {
	if (local_setting.app_setting.aircond_total_active > local_setting.app_setting.aircond_amount - 1) {
		local_setting.app_setting.aircond_total_active = local_setting.app_setting.aircond_amount - 1;
		if (local_setting.app_setting.aircond_total_active == 0) {
			local_setting.app_setting.aircond_total_active = 1;
		}
	}
}

void setting_total_air(void) {
	/*send msg to task seting*/
	task_post_pure_msg(SL_TASK_SETTING_ID, SL_SETTING_TOTAL_AIR_COND_UPDATE_REQ);
}

void increase_timer_air(void) {
	local_setting.app_setting.aircond_time_switch_interval ++;

	if (local_setting.app_setting.aircond_time_switch_interval == 25) {
		local_setting.app_setting.aircond_time_switch_interval = 1;
	}
}

void decrease_timer_air(void) {
	local_setting.app_setting.aircond_time_switch_interval --;

	if (local_setting.app_setting.aircond_time_switch_interval == 0 || local_setting.app_setting.aircond_time_switch_interval == 255 ) {
		local_setting.app_setting.aircond_time_switch_interval = 24;
	}
}

void setting_timer_air(void) {
	/*send msg to task seting*/
	task_post_pure_msg(SL_TASK_SETTING_ID, SL_SETTING_RANGE_TIME_AIR_COND_UPDATE_REQ);
}

/* inc & decr temperature AIRCOND active & backup */
void increase_temp_air_active_low(void) {
	local_setting.app_setting.aircond_active_temp_low ++;

	if (local_setting.app_setting.aircond_active_temp_low > TEMP_AIR_ACTIVE_LOW_MAX) {
		local_setting.app_setting.aircond_active_temp_low = TEMP_AIR_ACTIVE_LOW_MIN;
	}
}

void decrease_temp_air_active_low(void) {
	local_setting.app_setting.aircond_active_temp_low --;

	if (local_setting.app_setting.aircond_active_temp_low < TEMP_AIR_ACTIVE_LOW_MIN) {
		local_setting.app_setting.aircond_active_temp_low = TEMP_AIR_ACTIVE_LOW_MAX;
	}
}

void increase_temp_air_active_high(void) {
	local_setting.app_setting.aircond_active_temp_high ++;

	if (local_setting.app_setting.aircond_active_temp_high > TEMP_AIR_ACTIVE_HIGH_MAX) {
		local_setting.app_setting.aircond_active_temp_high = local_setting.app_setting.aircond_active_temp_low + 3;
	}
}

void decrease_temp_air_active_high(void) {
	local_setting.app_setting.aircond_active_temp_high --;

	if (local_setting.app_setting.aircond_active_temp_high < local_setting.app_setting.aircond_active_temp_low + 3) {
		local_setting.app_setting.aircond_active_temp_high = TEMP_AIR_ACTIVE_HIGH_MAX;
	}
}

void increase_temp_air_backup_low(void) {
	local_setting.app_setting.aircond_backup_temp_low ++;

	if (local_setting.app_setting.aircond_backup_temp_low > TEMP_AIR_BACKUP_LOW_MAX) {
		local_setting.app_setting.aircond_backup_temp_low = local_setting.app_setting.aircond_active_temp_low + 1;
	}
}

void decrease_temp_air_backup_low(void) {
	local_setting.app_setting.aircond_backup_temp_low --;

	if (local_setting.app_setting.aircond_backup_temp_low < local_setting.app_setting.aircond_active_temp_low+ 1) {
		local_setting.app_setting.aircond_backup_temp_low = TEMP_AIR_BACKUP_LOW_MAX;
	}
}

void increase_temp_air_backup_high(void) {
	local_setting.app_setting.aircond_backup_temp_high ++;

	if (local_setting.app_setting.aircond_backup_temp_high > TEMP_AIR_BACKUP_HIGH_MAX) {
		local_setting.app_setting.aircond_backup_temp_high = local_setting.app_setting.aircond_backup_temp_low + 2;
	}
}

void decrease_temp_air_backup_high(void) {
	local_setting.app_setting.aircond_backup_temp_high --;

	if (local_setting.app_setting.aircond_backup_temp_high < local_setting.app_setting.aircond_backup_temp_low + 2) {
		local_setting.app_setting.aircond_backup_temp_high = TEMP_AIR_BACKUP_HIGH_MAX;
	}
}

void check_value_temp_air() {
	if (local_setting.app_setting.aircond_active_temp_high < local_setting.app_setting.aircond_active_temp_low + 3) {
		local_setting.app_setting.aircond_active_temp_high = local_setting.app_setting.aircond_active_temp_low + 3;
	}
	if (local_setting.app_setting.aircond_backup_temp_low < local_setting.app_setting.aircond_active_temp_low + 1) {
		local_setting.app_setting.aircond_backup_temp_low = local_setting.app_setting.aircond_active_temp_low + 1;
	}
	if (local_setting.app_setting.aircond_backup_temp_high < local_setting.app_setting.aircond_backup_temp_low + 2) {
		local_setting.app_setting.aircond_backup_temp_high = local_setting.app_setting.aircond_backup_temp_low + 2;
	}
}

/* inc & decr temperature FAN backup*/
void increase_temp_fan_backup_low(void) {
	local_setting.app_setting.fan_backup_temp_low ++;

	if (local_setting.app_setting.fan_backup_temp_low > TEMP_FAN_BACKUP_LOW_MAX) {
		local_setting.app_setting.fan_backup_temp_low = TEMP_FAN_BACKUP_LOW_MIN;
	}
}

void decrease_temp_fan_backup_low(void) {
	local_setting.app_setting.fan_backup_temp_low --;

	if (local_setting.app_setting.fan_backup_temp_low < TEMP_FAN_BACKUP_LOW_MIN) {
		local_setting.app_setting.fan_backup_temp_low = TEMP_FAN_BACKUP_LOW_MAX;
	}
}

void increase_temp_fan_backup_high(void) {
	local_setting.app_setting.fan_backup_temp_high ++;

	if (local_setting.app_setting.fan_backup_temp_high > TEMP_FAN_BACKUP_HIGH_MAX) {
		local_setting.app_setting.fan_backup_temp_high = local_setting.app_setting.fan_backup_temp_low + 2;
	}
}

void decrease_temp_fan_backup_high(void) {
	local_setting.app_setting.fan_backup_temp_high --;

	if (local_setting.app_setting.fan_backup_temp_high < local_setting.app_setting.fan_backup_temp_low + 2) {
		local_setting.app_setting.fan_backup_temp_high = TEMP_FAN_BACKUP_HIGH_MAX;
	}
}

void check_value_temp_fan() {
	if (local_setting.app_setting.fan_backup_temp_high < local_setting.app_setting.fan_backup_temp_low + 2) {
		local_setting.app_setting.fan_backup_temp_high = local_setting.app_setting.fan_backup_temp_low + 2;
	}
}

void setting_temp_air(void) {
	/*send msg to task seting*/
	task_post_pure_msg(SL_TASK_SETTING_ID, SL_SETTING_TEMP_AIR_COND_UPDATE_REQ);
}

void ctrl_scr_air_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		switch (scr_air_setting.focus_item) {
		case 1:
			SCREEN_TRAN(ctrl_scr_air_total_setting, &scr_air_total_setting);
			break;

		case 2:
			SCREEN_TRAN(ctrl_scr_air_timer_setting, &scr_air_timer_setting);
			break;

		case 3:
			SCREEN_TRAN(ctrl_scr_air_temp_setting, &scr_air_temp_setting);
			break;

		case 4: {
			scr_air_setting.focus_item = 1;
			scr_air_setting.focus_item_before = 1;
			scr_air_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_main_setting, &scr_main_setting);
		}
			break;

		default:
			break;
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		btn_down_focus_taget(&scr_air_setting, 5, 1);
		break;

	case SL_UI_BUTTON_UP_PRESS:
		btn_up_focus_taget(&scr_air_setting, 5, 1);
		break;

	default:
		break;
	}
}

void ctrl_scr_air_total_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS:
		if (item_setting == 0 && scr_air_total_setting.focus_item != 3) {
			item_setting = 1;
			item_setting_flag = 1;

			scr_air_total_setting.focus_item_before = scr_air_total_setting.focus_item;
			scr_air_total_setting.focus_item_after = scr_air_total_setting.focus_item;

			((view_rectangle_t*) scr_air_total_setting.item[scr_air_total_setting.focus_item])->focus_cursor = 0;
			((view_rectangle_t*) scr_air_total_setting.item[scr_air_total_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_air_total_setting.item[scr_air_total_setting.focus_item])->border_width = 0;
		}
		else if (scr_air_total_setting.focus_item == 3) {
			if (item_setting_flag == 1) {
				item_setting_flag = 0;
				setting_total_air();
			}

			reset_item_setting();

			scr_air_total_setting.focus_item = 1;
			scr_air_total_setting.focus_item_before = 1;
			scr_air_total_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_air_setting, &scr_air_setting);
		}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_air_total_setting, 4 , 1);
		}
		else {
			if (scr_air_total_setting.focus_item == 1) {
				decrease_total_aircond();
			}
			else {
				decrease_total_aircond_active();
			}
		}
		break;

	case SL_UI_BUTTON_UP_PRESS:
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_air_total_setting, 4, 1);
		}
		else {
			if (scr_air_total_setting.focus_item == 1) {
				increase_total_aircond();
			}
			else {
				increase_total_aircond_active();
			}
		}
		break;

	default:
		break;
	}

	check_value_total_air();

	xsprintf(((view_rectangle_t*) scr_air_total_setting.item[1])->text,"%02d", local_setting.app_setting.aircond_amount);
	xsprintf(((view_rectangle_t*) scr_air_total_setting.item[2])->text,"%02d", local_setting.app_setting.aircond_total_active);
}

void ctrl_scr_air_timer_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		if (item_setting == 0 && scr_air_timer_setting.focus_item == 1) {
			item_setting = 1;
			item_setting_flag = 1;

			scr_air_timer_setting.focus_item_before = scr_air_timer_setting.focus_item;
			scr_air_timer_setting.focus_item_after = scr_air_timer_setting.focus_item;

			((view_rectangle_t*) scr_air_timer_setting.item[scr_air_timer_setting.focus_item])->focus_cursor = 0;
			((view_rectangle_t*) scr_air_timer_setting.item[scr_air_timer_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_air_timer_setting.item[scr_air_timer_setting.focus_item])->border_width = 0;
		}
		else if (scr_air_timer_setting.focus_item == 2) {
			if (item_setting_flag == 1) {
				item_setting_flag = 0;
				setting_timer_air();
			}

			reset_item_setting();

			scr_air_timer_setting.focus_item = 1;
			scr_air_timer_setting.focus_item_before = 1;
			scr_air_timer_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_air_setting, &scr_air_setting);
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_air_timer_setting, 3, 1);
		}
		else {
			decrease_timer_air();
		}
		break;

	case SL_UI_BUTTON_UP_PRESS:
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_air_timer_setting, 3, 1);
		}
		else {
			increase_timer_air();
		}
		break;

	default:
		break;
	}

	xsprintf(((view_rectangle_t*)scr_air_timer_setting.item[1])->text,"%02d",local_setting.app_setting.aircond_time_switch_interval);
}

void ctrl_scr_air_temp_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		if (scr_air_temp_setting.focus_item == 1) {
			SCREEN_TRAN(ctrl_scr_air_temp_aircond_setting, &scr_air_temp_aircond_setting);
		}
		else if (scr_air_temp_setting.focus_item == 2) {
			SCREEN_TRAN(ctrl_scr_air_temp_fan_setting, &scr_air_temp_fan_setting);
		}
		else {
			scr_air_temp_setting.focus_item = 1;
			scr_air_temp_setting.focus_item_before = 1;
			scr_air_temp_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_air_setting, &scr_air_setting);
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		btn_down_focus_taget(&scr_air_temp_setting, 4, 1);
		break;

	case SL_UI_BUTTON_UP_PRESS:
		btn_up_focus_taget(&scr_air_temp_setting, 4, 1);
		break;

	default:
		break;
	}
}

void ctrl_scr_air_temp_aircond_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS:
		if (item_setting == 0 && scr_air_temp_aircond_setting.focus_item != 5) {
			item_setting = 1;
			item_setting_flag = 1;

			scr_air_temp_aircond_setting.focus_item_before = scr_air_temp_aircond_setting.focus_item;
			scr_air_temp_aircond_setting.focus_item_after = scr_air_temp_aircond_setting.focus_item;

			((view_rectangle_t*) scr_air_temp_aircond_setting.item[scr_air_temp_aircond_setting.focus_item])->focus_cursor = 0;
			((view_rectangle_t*) scr_air_temp_aircond_setting.item[scr_air_temp_aircond_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_air_temp_aircond_setting.item[scr_air_temp_aircond_setting.focus_item])->border_width = 0;
		}
		else if (scr_air_temp_aircond_setting.focus_item == 5) {
			if (item_setting_flag == 1) {
				item_setting_flag = 0;
				setting_temp_air();
			}

			reset_item_setting();

			scr_air_temp_aircond_setting.focus_item = 1;
			scr_air_temp_aircond_setting.focus_item_before = 1;
			scr_air_temp_aircond_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_air_temp_setting, &scr_air_temp_setting);
		}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_air_temp_aircond_setting, NUMBER_SCREEN_ITEMS_MAX , 1);
		}
		else {
			if (scr_air_temp_aircond_setting.focus_item == 1) {
				decrease_temp_air_active_low();
			}
			else if (scr_air_temp_aircond_setting.focus_item == 2) {
				decrease_temp_air_active_high();
			}
			else if (scr_air_temp_aircond_setting.focus_item == 3) {
				decrease_temp_air_backup_low();
			}
			else {
				decrease_temp_air_backup_high();

			}
		}

		break;

	case SL_UI_BUTTON_UP_PRESS:
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_air_temp_aircond_setting, NUMBER_SCREEN_ITEMS_MAX, 1);
		}
		else {
			if (scr_air_temp_aircond_setting.focus_item == 1) {
				increase_temp_air_active_low();
			}
			else if (scr_air_temp_aircond_setting.focus_item == 2) {
				increase_temp_air_active_high();
			}
			else if (scr_air_temp_aircond_setting.focus_item == 3) {
				increase_temp_air_backup_low();
			}
			else {
				increase_temp_air_backup_high();
			}
		}
		break;

	default:
		break;
	}

	check_value_temp_air();

	xsprintf(((view_rectangle_t*) scr_air_temp_aircond_setting.item[1])->text,"%02d", local_setting.app_setting.aircond_active_temp_low);
	xsprintf(((view_rectangle_t*) scr_air_temp_aircond_setting.item[2])->text,"%02d", local_setting.app_setting.aircond_active_temp_high);
	xsprintf(((view_rectangle_t*) scr_air_temp_aircond_setting.item[3])->text,"%02d", local_setting.app_setting.aircond_backup_temp_low);
	xsprintf(((view_rectangle_t*) scr_air_temp_aircond_setting.item[4])->text,"%02d", local_setting.app_setting.aircond_backup_temp_high);
}

void ctrl_scr_air_temp_fan_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS:
		if (item_setting == 0 && scr_air_temp_fan_setting.focus_item != 3) {
			item_setting = 1;
			item_setting_flag = 1;

			scr_air_temp_fan_setting.focus_item_before = scr_air_temp_fan_setting.focus_item;
			scr_air_temp_fan_setting.focus_item_after = scr_air_temp_fan_setting.focus_item;

			((view_rectangle_t*) scr_air_temp_fan_setting.item[scr_air_temp_fan_setting.focus_item])->focus_cursor = 0;
			((view_rectangle_t*) scr_air_temp_fan_setting.item[scr_air_temp_fan_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_air_temp_fan_setting.item[scr_air_temp_fan_setting.focus_item])->border_width = 0;
		}
		else if (scr_air_temp_fan_setting.focus_item == 3) {
			if (item_setting_flag == 1) {
				item_setting_flag = 0;
				setting_temp_air();
			}

			reset_item_setting();

			scr_air_temp_fan_setting.focus_item = 1;
			scr_air_temp_fan_setting.focus_item_before = 1;
			scr_air_temp_fan_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_air_temp_setting, &scr_air_temp_setting);
		}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_air_temp_fan_setting, 4 , 1);
		}
		else {
			if (scr_air_temp_fan_setting.focus_item == 1) {
				decrease_temp_fan_backup_low();
			}
			else {
				decrease_temp_fan_backup_high();
			}
		}
		break;

	case SL_UI_BUTTON_UP_PRESS:
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_air_temp_fan_setting, NUMBER_SCREEN_ITEMS_MAX, 1);
		}
		else {
			if (scr_air_temp_fan_setting.focus_item == 1) {
				increase_temp_fan_backup_low();
			}
			else {
				increase_temp_fan_backup_high();
			}
		}
		break;

	default:
		break;
	}

	check_value_temp_fan();

	xsprintf(((view_rectangle_t*) scr_air_temp_fan_setting.item[1])->text,"%02d", local_setting.app_setting.fan_backup_temp_low);
	xsprintf(((view_rectangle_t*) scr_air_temp_fan_setting.item[2])->text,"%02d", local_setting.app_setting.fan_backup_temp_high);

}

/*****************************************************************************/
/* ENGINEER SETTING screen
 */
/*****************************************************************************/

void ctrl_scr_engineer_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		if (scr_engineer_setting.focus_item == 1) {
			SCREEN_TRAN(ctrl_scr_engineer_network_setting, &scr_engineer_network_setting);
		}
		else if (scr_engineer_setting.focus_item == 2) {
			SCREEN_TRAN(ctrl_scr_engineer_change_mode, &scr_engineer_change_mode);
		}
		else if (scr_engineer_setting.focus_item == 3) {
			SCREEN_TRAN(ctrl_scr_engineer_control_output_setting, &scr_engineer_control_output_setting);
		}
		else if (scr_engineer_setting.focus_item == 4) {
			SCREEN_TRAN(ctrl_scr_engineer_calib_setting, &scr_engineer_calib_setting);
		}
		else {
			scr_engineer_setting.focus_item = 1;
			scr_engineer_setting.focus_item_before = 1;
			scr_engineer_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_main_setting, &scr_main_setting);
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		btn_down_focus_taget(&scr_engineer_setting, 6, 1);
		break;

	case SL_UI_BUTTON_UP_PRESS:
		btn_up_focus_taget(&scr_engineer_setting, 6, 1);
		break;

	default:
		break;
	}
}

void increase_node_chanel(void) {
	ac_network_config.node_chanel ++;

	if (ac_network_config.node_chanel > 126) {
		ac_network_config.node_chanel = 0;
	}
}

void decrease_node_chanel(void) {
	ac_network_config.node_chanel --;

	if (ac_network_config.node_chanel == 255) {
		ac_network_config.node_chanel = 125;
	}
}

void increase_node_address(void) {
	ac_network_config.node_addr ++;

	if (ac_network_config.node_addr > 100) {
		ac_network_config.node_addr = 0;
	}
}

void decrease_node_address(void) {
	ac_network_config.node_addr --;

	if (ac_network_config.node_addr == 255) {
		ac_network_config.node_addr = 100;
	}
}

void increase_node_server_addr(void) {
	ac_network_config.node_server_addr ++;

	if (ac_network_config.node_server_addr > 100) {
		ac_network_config.node_server_addr = 0;
	}
}

void decrease_node_server_adrr(void) {
	ac_network_config.node_server_addr --;

	if (ac_network_config.node_server_addr == 255) {
		ac_network_config.node_server_addr = 100;
	}
}

void setting_node_server(void) {
	task_post_pure_msg(SL_TASK_SETTING_ID, SL_SETTING_NETWORK_INFO_UPDATE_REQ);
}

void ctrl_scr_engineer_network_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS:
		if (item_setting == 0 && scr_engineer_network_setting.focus_item != 4) {
			item_setting = 1;
			item_setting_flag = 1;

			scr_engineer_network_setting.focus_item_before = scr_engineer_network_setting.focus_item;
			scr_engineer_network_setting.focus_item_after = scr_engineer_network_setting.focus_item;

			((view_rectangle_t*) scr_engineer_network_setting.item[scr_engineer_network_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_engineer_network_setting.item[scr_engineer_network_setting.focus_item])->border_width = 0;
		}
		else if (scr_engineer_network_setting.focus_item == 4) {
			if (item_setting_flag == 1) {
				item_setting_flag = 0;
				setting_node_server();
			}

			reset_item_setting();

			scr_engineer_network_setting.focus_item = 1;
			scr_engineer_network_setting.focus_item_before = 1;
			scr_engineer_network_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_engineer_setting, &scr_engineer_setting);
		}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_engineer_network_setting, 5, 1);
		}
		else {
			if (scr_air_temp_setting.focus_item == 1) {
				decrease_node_chanel();
			}
			else if (scr_air_temp_setting.focus_item == 2) {
				decrease_node_address();
			}
			else if (scr_air_temp_setting.focus_item == 3) {
				decrease_node_server_adrr();
			}
		}

		break;

	case SL_UI_BUTTON_UP_PRESS:
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_engineer_network_setting, 5, 1);
		}
		else {
			if (scr_air_temp_setting.focus_item == 1) {
				increase_node_chanel();
			}
			else if (scr_air_temp_setting.focus_item == 2) {
				increase_node_address();
			}
			else if (scr_air_temp_setting.focus_item == 3) {
				increase_node_server_addr();
			}
		}
		break;

	default:
		break;
	}

	xsprintf(((view_rectangle_t*) scr_engineer_network_setting.item[1])->text,"Node chanel : %03d", ac_network_config.node_chanel);
	xsprintf(((view_rectangle_t*) scr_engineer_network_setting.item[2])->text,"Node addr   : %03d", ac_network_config.node_addr);
	xsprintf(((view_rectangle_t*) scr_engineer_network_setting.item[3])->text,"Serv addr   : %03d", ac_network_config.node_server_addr);
}

void increase_app_mode(void) {
	local_setting.app_setting.aircond_mode ++;

	if (local_setting.app_setting.aircond_mode > AIR_COND_MODE_CRITICAL) {
		local_setting.app_setting.aircond_mode = AIR_COND_MODE_AUTO;
	}
}

void decrease_app_mode(void) {
	local_setting.app_setting.aircond_mode --;

	if (local_setting.app_setting.aircond_mode == 0) {
		local_setting.app_setting.aircond_mode = AIR_COND_MODE_CRITICAL;
	}
}

void ctrl_scr_engineer_change_mode(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS:
		if (item_setting == 0 && scr_engineer_change_mode.focus_item != 2) {
			item_setting = 1;
			item_setting_flag = 1;

			scr_engineer_change_mode.focus_item_before = scr_engineer_change_mode.focus_item;
			scr_engineer_change_mode.focus_item_after = scr_engineer_change_mode.focus_item;

			((view_rectangle_t*) scr_engineer_change_mode.item[scr_engineer_change_mode.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_engineer_change_mode.item[scr_engineer_change_mode.focus_item])->border_width = 0;
		}
		else if (scr_engineer_change_mode.focus_item == 2) {
			if (item_setting_flag == 1) {
				item_setting_flag = 0;
			}

			reset_item_setting();

			scr_engineer_change_mode.focus_item = 1;
			scr_engineer_change_mode.focus_item_before = 1;
			scr_engineer_change_mode.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_engineer_setting, &scr_engineer_setting);
		}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_engineer_change_mode, 3, 1);
		}
		else {
			decrease_app_mode();
		}

		break;

	case SL_UI_BUTTON_UP_PRESS:
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_engineer_change_mode, 3, 1);
		}
		else {
			increase_app_mode();
		}

		break;

	default:
		break;
	}

	memset(scr_engineer_change_mode.item[1], 0, sizeof(uint8_t) * RECTANGLE_TEXT_LENGH_MAX);

	switch(local_setting.app_setting.aircond_mode) {
	case AIR_COND_MODE_AUTO:
		((view_rectangle_t*) scr_engineer_change_mode.item[1])->focus_size = 4;
		xsprintf(((view_rectangle_t*) scr_engineer_change_mode.item[1])->text,"AUTO");
		break;

	case AIR_COND_MODE_MANUAL:
		((view_rectangle_t*) scr_engineer_change_mode.item[1])->focus_size = 5;
		xsprintf(((view_rectangle_t*) scr_engineer_change_mode.item[1])->text,"MANUAL");
		break;

	case AIR_COND_MODE_CRITICAL:
		((view_rectangle_t*) scr_engineer_change_mode.item[1])->focus_size = 7;
		xsprintf(((view_rectangle_t*) scr_engineer_change_mode.item[1])->text,"CRITICAL");
		break;

	default:
		break;
	}
}

void ctrl_scr_engineer_control_output_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		if (scr_engineer_control_output_setting.focus_item == 1) {
			SCREEN_TRAN(ctrl_scr_engineer_control_aircond_setting, &scr_engineer_control_aircond_setting);
		}
		else if (scr_engineer_control_output_setting.focus_item == 2) {
			SCREEN_TRAN(ctrl_scr_engineer_control_general_output_setting, &scr_engineer_control_general_output_setting);
		}
		else {
			scr_engineer_control_output_setting.focus_item = 1;
			scr_engineer_control_output_setting.focus_item_before = 1;
			scr_engineer_control_output_setting.focus_item_after = 1;
			SCREEN_TRAN(ctrl_scr_engineer_setting, &scr_engineer_setting);
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		btn_down_focus_taget(&scr_engineer_control_output_setting, 4, 1);
		break;

	case SL_UI_BUTTON_UP_PRESS:
		btn_up_focus_taget(&scr_engineer_control_output_setting, 4, 1);
		break;

	default:
		break;
	}
}

void ctrl_scr_engineer_control_aircond_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		for (uint8_t i = 0; i < local_setting.app_setting.aircond_amount; i++) {
			air_cond_current_status[i]= relay_aircond_status[i];
		}
		break;

	case SL_UI_BUTTON_MODE_PRESS:
		if (item_setting == 0 && scr_engineer_control_aircond_setting.focus_item != 1) {
			item_setting = 1;

			scr_engineer_control_aircond_setting.focus_item_before = scr_engineer_control_aircond_setting.focus_item;
			scr_engineer_control_aircond_setting.focus_item_after = scr_engineer_control_aircond_setting.focus_item;

			((view_rectangle_t*) scr_engineer_control_aircond_setting.item[scr_engineer_control_aircond_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_engineer_control_aircond_setting.item[scr_engineer_control_aircond_setting.focus_item])->border_width = 0;
		}
		else if (scr_engineer_control_aircond_setting.focus_item == 1) {
			reset_item_setting();

			scr_engineer_control_aircond_setting.focus_item = 1;
			scr_engineer_control_aircond_setting.focus_item_before = 1;
			scr_engineer_control_aircond_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_engineer_control_output_setting, &scr_engineer_control_output_setting);
		}
		break;

	case SL_UI_BUTTON_UP_PRESS: {
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_engineer_control_aircond_setting, local_setting.app_setting.aircond_amount + 2, 1);
		}
		else {
			air_cond_current_status[scr_engineer_control_aircond_setting.focus_item - 2] = AIR_COND_ON;
			task_post_pure_msg(SL_TASK_CTRL_POP_ID, SL_RL_AIR_COND_CONTROL_REQ);
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS: {
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_engineer_control_aircond_setting, local_setting.app_setting.aircond_amount + 2, 1);
		}
		else {
			air_cond_current_status[scr_engineer_control_aircond_setting.focus_item - 2] = AIR_COND_OFF;
			task_post_pure_msg(SL_TASK_CTRL_POP_ID, SL_RL_AIR_COND_CONTROL_REQ);
		}
	}
		break;

	default:
		break;
	}

	for (uint8_t i = 0; i < local_setting.app_setting.aircond_amount; i++) {
		xsprintf(((view_rectangle_t*) scr_engineer_control_aircond_setting.item[i + 2])->text,"%s",((air_cond_current_status[i] == AIR_COND_ON) ? (" ON") : "OFF"));
	}
}

void ctrl_scr_engineer_control_general_output_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		for (uint8_t i = 0; i < SL_TOTAL_FAN_BACKUP; i++) {
			general_output_current_status[i] = relay_read_status_output(i);
		}
		break;

	case SL_UI_BUTTON_MODE_PRESS:
		if (item_setting == 0 && scr_engineer_control_general_output_setting.focus_item != 1) {
			item_setting = 1;

			scr_engineer_control_general_output_setting.focus_item_before = scr_engineer_control_general_output_setting.focus_item;
			scr_engineer_control_general_output_setting.focus_item_after = scr_engineer_control_general_output_setting.focus_item;

			((view_rectangle_t*) scr_engineer_control_general_output_setting.item[scr_engineer_control_general_output_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_engineer_control_general_output_setting.item[scr_engineer_control_general_output_setting.focus_item])->border_width = 0;
		}
		else if (scr_engineer_control_general_output_setting.focus_item == 1) {
			reset_item_setting();

			scr_engineer_control_general_output_setting.focus_item = 1;
			scr_engineer_control_general_output_setting.focus_item_before = 1;
			scr_engineer_control_general_output_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_engineer_control_output_setting, &scr_engineer_control_output_setting);
		}
		break;

	case SL_UI_BUTTON_UP_PRESS: {
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_engineer_control_general_output_setting, 4 + 2, 1);
		}
		else {
			general_output_current_status[scr_engineer_control_general_output_setting.focus_item - 2] = AIR_COND_ON;
			task_post_pure_msg(SL_TASK_CTRL_POP_ID, SL_RL_GENERAL_OUPUT_CONTROL_REQ);
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS: {
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_engineer_control_general_output_setting, 4 + 2, 1);
		}
		else {
			general_output_current_status[scr_engineer_control_general_output_setting.focus_item - 2] = AIR_COND_OFF;
			task_post_pure_msg(SL_TASK_CTRL_POP_ID, SL_RL_GENERAL_OUPUT_CONTROL_REQ);
		}
	}
		break;

	default:
		break;
	}

	for (uint8_t i = 0; i < SL_TOTAL_FAN_BACKUP; i++) {
		xsprintf(((view_rectangle_t*)scr_engineer_control_general_output_setting.item[i + 2])->text,"%s",((general_output_current_status[i]==AIR_COND_ON) ? (" ON") : "OFF"));
	}
}

void ctrl_scr_engineer_calib_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		if (scr_engineer_calib_setting.focus_item == 1) {
			SCREEN_TRAN(ctrl_scr_engineer_calib_current_air_setting, &scr_engineer_calib_current_air_setting);
		}
		else if (scr_engineer_calib_setting.focus_item == 2) {
			SCREEN_TRAN(ctrl_scr_engineer_calib_temp_hum_setting, &scr_engineer_calib_temp_hum_setting);
		}
		else {
			scr_engineer_calib_setting.focus_item = 1;
			scr_engineer_calib_setting.focus_item_before = 1;
			scr_engineer_calib_setting.focus_item_after = 1;
			SCREEN_TRAN(ctrl_scr_engineer_setting, &scr_engineer_setting);
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		btn_down_focus_taget(&scr_engineer_calib_setting, 4, 1);
		break;

	case SL_UI_BUTTON_UP_PRESS:
		btn_up_focus_taget(&scr_engineer_calib_setting, 4, 1);
		break;

	default:
		break;
	}
}

void increase_current_air(uint8_t air_cond_number) {
	air_cond[air_cond_number].milestone_on += 100;

	if(air_cond[air_cond_number].milestone_on >= 10000) {
		air_cond[air_cond_number].milestone_on = 500;
	}
}

void decrease_current_air(uint8_t air_cond_number) {
	air_cond[air_cond_number].milestone_on -= 100;

	if(air_cond[air_cond_number].milestone_on < 500 || air_cond[air_cond_number].milestone_on >= 10000) {
		air_cond[air_cond_number].milestone_on = 9900;
	}
}

void setting_current_air(void) {
	task_post_pure_msg(SL_TASK_SETTING_ID, SL_SETTING_MILESTONE_AIR_COND_ON_UPDATE_REQ);
}

void ctrl_scr_engineer_calib_current_air_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS:
		if (item_setting == 0 && scr_engineer_calib_current_air_setting.focus_item != 1) {
			item_setting = 1;
			item_setting_flag = 1;

			scr_engineer_calib_current_air_setting.focus_item_before = scr_engineer_calib_current_air_setting.focus_item;
			scr_engineer_calib_current_air_setting.focus_item_after  = scr_engineer_calib_current_air_setting.focus_item;

			((view_rectangle_t*) scr_engineer_calib_current_air_setting.item[scr_engineer_calib_current_air_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_engineer_calib_current_air_setting.item[scr_engineer_calib_current_air_setting.focus_item])->border_width = 0;
		}
		else if (scr_engineer_calib_current_air_setting.focus_item == 1) {
			if (item_setting_flag == 1) {
				item_setting_flag = 0;
				setting_current_air();
			}

			reset_item_setting();

			scr_engineer_calib_current_air_setting.focus_item = 1;
			scr_engineer_calib_current_air_setting.focus_item_before = 1;
			scr_engineer_calib_current_air_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_engineer_calib_setting, &scr_engineer_calib_setting);
		}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_engineer_calib_current_air_setting, local_setting.app_setting.aircond_amount + 2, 1);
		}
		else {
			decrease_current_air(scr_engineer_calib_current_air_setting.focus_item - 2);
		}
		break;

	case SL_UI_BUTTON_UP_PRESS:
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_engineer_calib_current_air_setting, local_setting.app_setting.aircond_amount + 2, 1);
		}
		else {
			increase_current_air(scr_engineer_calib_current_air_setting.focus_item - 2);
		}
		break;

	default:
		break;
	}

	for (uint8_t i = 0; i < local_setting.app_setting.aircond_amount; i++) {
		xsprintf(((view_rectangle_t*) scr_engineer_calib_current_air_setting.item[i + 2])->text,"%04d", air_cond[i].milestone_on);
	}
}

void invert_operations_temp(void) {
	local_setting.calib_temp_1_opt = ~ local_setting.calib_temp_1_opt;
}

void invert_operations_hum(void) {
	local_setting.calib_hum_opt = ~ local_setting.calib_hum_opt;
}

void increase_temp_calib(void) {
	local_setting.calib_temp_1_val ++;

	if (local_setting.calib_temp_1_val > MAX_CALIB_TEMP) {
		local_setting.calib_temp_1_val = 0;
	}
}

void decrease_temp_calib(void) {
	local_setting.calib_temp_1_val --;

	if (local_setting.calib_temp_1_val == 255) {
		local_setting.calib_temp_1_val = MAX_CALIB_TEMP;
	}
}

void increase_hum_calib(void) {
	local_setting.calib_hum_val ++;

	if (local_setting.calib_hum_val > MAX_CALIB_HUM ) {
		local_setting.calib_hum_val = 0;
	}
}

void decrease_hum_calib(void) {
	local_setting.calib_hum_val --;

	if (local_setting.calib_hum_val == 255 ) {
		local_setting.calib_hum_val = MAX_CALIB_HUM;
	}
}

void setting_temp_hum(void) {
	task_post_pure_msg(SL_TASK_SETTING_ID, SL_SETTING_RANGE_TIME_AIR_COND_UPDATE_REQ);
}

void ctrl_scr_engineer_calib_temp_hum_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS:
		if (item_setting == 0 && scr_engineer_calib_temp_hum_setting.focus_item != 5) {
			item_setting = 1;
			item_setting_flag = 1;

			scr_engineer_calib_temp_hum_setting.focus_item_before = scr_engineer_calib_temp_hum_setting.focus_item;
			scr_engineer_calib_temp_hum_setting.focus_item_after  = scr_engineer_calib_temp_hum_setting.focus_item;

			((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[scr_engineer_calib_temp_hum_setting.focus_item])->border_width = 1;
		}
		else if (item_setting == 1) {
			reset_item_setting();

			((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[scr_engineer_calib_temp_hum_setting.focus_item])->border_width = 0;
		}
		else if (scr_engineer_calib_temp_hum_setting.focus_item == 5) {
			if (item_setting_flag == 1) {
				item_setting_flag = 0;
				setting_temp_hum();
			}

			reset_item_setting();

			scr_engineer_calib_temp_hum_setting.focus_item = 1;
			scr_engineer_calib_temp_hum_setting.focus_item_before = 1;
			scr_engineer_calib_temp_hum_setting.focus_item_after = 1;

			SCREEN_TRAN(ctrl_scr_engineer_calib_setting, &scr_engineer_calib_setting);
		}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		if (item_setting == 0) {
			btn_down_focus_taget(&scr_engineer_calib_temp_hum_setting, 6, 1);
		}
		else {
			if (scr_engineer_calib_temp_hum_setting.focus_item == 1) {
				invert_operations_temp();
			}
			else if (scr_engineer_calib_temp_hum_setting.focus_item == 2) {
				decrease_temp_calib();
			}
			else if (scr_engineer_calib_temp_hum_setting.focus_item == 3) {
				invert_operations_hum();
			}
			else {
				decrease_hum_calib();
			}
		}
		break;

	case SL_UI_BUTTON_UP_PRESS:
		if (item_setting == 0) {
			btn_up_focus_taget(&scr_engineer_calib_temp_hum_setting, 6, 1);
		}
		else {
			if (scr_engineer_calib_temp_hum_setting.focus_item == 1) {
				invert_operations_temp();
			}
			else if (scr_engineer_calib_temp_hum_setting.focus_item == 2) {
				increase_temp_calib();
			}
			else if (scr_engineer_calib_temp_hum_setting.focus_item == 3) {
				invert_operations_hum();
			}
			else {
				increase_hum_calib();
			}
		}
		break;

	default:
		break;
	}

	xsprintf(((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[1])->text,"%s",(local_setting.calib_temp_1_opt ? ("+") : "-"));
	xsprintf(((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[2])->text,"%02d", local_setting.calib_temp_1_val);
	xsprintf(((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[3])->text,"%s",(local_setting.calib_hum_opt ? ("+") : "-"));
	xsprintf(((view_rectangle_t*) scr_engineer_calib_temp_hum_setting.item[4])->text,"%02d", local_setting.calib_hum_val);
}


/*****************************************************************************/
/* DEFAULT SETTING screen
 */
/*****************************************************************************/

void ctrl_scr_default_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		break;

	case SL_UI_BUTTON_MODE_PRESS: {
		if (scr_default_setting.focus_item == 1) {
			SCREEN_TRAN(ctrl_scr_main_setting, &scr_main_setting);
		}
		else {
			task_post_pure_msg(SL_TASK_SETTING_ID, SL_SETTING_FLASH_INIT_UPDATE_REQ);
		}
	}
		break;

	case SL_UI_BUTTON_DOWN_PRESS:
		btn_down_focus_taget(&scr_default_setting, 3, 1);
		break;

	case SL_UI_BUTTON_UP_PRESS:
		btn_up_focus_taget(&scr_default_setting, 3, 1);
		break;

	case SL_SETTING_UI_INIT_FLASH_OK_RES:
		scr_default_setting.focus_item = 1;
		SCREEN_TRAN(ctrl_scr_default_ok_setting, &scr_default_ok_setting);
		break;

	case SL_SETTING_UI_INIT_FLASH_NG_RES:
		scr_default_setting.focus_item = 1;
		SCREEN_TRAN(ctrl_scr_default_fail_setting, &scr_default_fail_setting);
		break;

	default:
		break;
	}
}

void ctrl_scr_default_ok_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		timer_set(SL_TASK_UI_ID, SL_UI_SCREEN_INIT_FLASH_OUT, SL_UI_TIMER_FLASH_INIT_INTERVAL, TIMER_ONE_SHOT);
		break;

	case SL_UI_SCREEN_INIT_FLASH_OUT:
		SCREEN_TRAN(ctrl_scr_main_setting, &scr_main_setting);
		break;

	default:
		break;
	}
}

void ctrl_scr_default_fail_setting(ak_msg_t* msg) {
	switch (msg->sig) {
	case SCREEN_ENTRY :
		timer_set(SL_TASK_UI_ID, SL_UI_SCREEN_INIT_FLASH_OUT, SL_UI_TIMER_FLASH_INIT_INTERVAL, TIMER_ONE_SHOT);
		break;

	case SL_UI_SCREEN_INIT_FLASH_OUT:
		SCREEN_TRAN(ctrl_scr_default_setting, &scr_default_setting);
		break;

	default:
		break;
	}
}
