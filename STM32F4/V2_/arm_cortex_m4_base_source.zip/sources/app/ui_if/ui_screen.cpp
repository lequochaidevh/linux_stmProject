#include "sys_dbg.h"
#include "sys_io.h"
#include "sys_ctrl.h"

#include "app.h"
#include "app_dbg.h"

#include "task_list.h"
#include "task_sm.h"
#include "task_ui.h"
//#include "task_sensor.h"
//#include "task_setting.h"
//#include "task_ctrl_pop.h"

#include "utils.h"
#include "xprintf.h"

#include "ui_screen.h"

static void view_scr_main();
static void view_scr_main_current_aircond();
static void view_scr_main_parameter_setting();
static void view_scr_main_network_gateway();
static void view_scr_setting_busy();
static void view_scr_firmware_update();
static void view_scr_main_tilde_setting();
static void view_scr_time_tilde_setting();

static void view_scr_air_tilde_setting();
static void view_scr_air_total_tilde_setting();
static void view_scr_air_timer_tilde_setting();
static void view_scr_air_temp_tilde_setting();
static void view_scr_air_temp_aircond_tilde_setting();
static void view_scr_air_temp_fan_tilde_setting();

static void view_scr_engineer_tilde_setting();
static void view_scr_engineer_network_tilde_settings();
static void view_scr_engineer_change_mode_tilde_settings();
static void view_scr_engineer_control_output_tilde_settings();
static void view_scr_engineer_control_aircond_tilde_settings();
static void view_scr_engineer_control_general_output_tilde_settings();
static void view_scr_engineer_calib_settings();
static void view_engineer_calib_current_air_setting();
static void view_engineer_calib_temp_hum_setting();

static void view_scr_default_tilde_setting();
static void view_scr_default_setting_ok();
static void view_scr_default_setting_fail();

/**
 ******************************************************************************
 * objects MAIN SCREEN
 *
 ******************************************************************************
 */

/*----------[[[ITERM]]]------------*/

view_dynamic_t dyn_view_main = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_main
};

view_dynamic_t dyn_view_main_current_aircond = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_main_current_aircond
};

view_dynamic_t dyn_view_main_parmeter_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_main_parameter_setting
};

view_dynamic_t dyn_view_main_network_gateway = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_main_network_gateway
};

view_dynamic_t dyn_view_system_busy = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_setting_busy
};

view_dynamic_t dyn_view_firmware_update = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_firmware_update
};

/*----------[[[OBJECT]]]------------*/
view_screen_t scr_main = {
	&dyn_view_main,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 0,
	.focus_item_before = 0,
	.focus_item_after = 0,
};

view_screen_t scr_main_current_aircond = {
	&dyn_view_main_current_aircond,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 0,
	.focus_item_before = 0,
	.focus_item_after = 0,
};

view_screen_t scr_main_app_setting = {
	&dyn_view_main_parmeter_setting,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 0,
	.focus_item_before = 0,
	.focus_item_after = 0,
};

view_screen_t scr_main_network_gateway = {
	&dyn_view_main_network_gateway,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 0,
	.focus_item_before = 0,
	.focus_item_after = 0,
};

view_screen_t scr_system_busy = {
	&dyn_view_system_busy,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 0,
	.focus_item_before = 0,
	.focus_item_after = 0,
};

view_screen_t scr_firmware_update = {
	&dyn_view_firmware_update,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 0,
	.focus_item_before = 0,
	.focus_item_after = 0,
};

/**
 ******************************************************************************
 * objects MAIN SCREEN SETTING
 *
 ******************************************************************************
 */

/*----------[[[ITERM]]]------------*/
view_dynamic_t dyn_view_main_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_main_tilde_setting
};

view_rectangle_t rec_view_time = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'T','i','m','e'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 12,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_air = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'A','i','r'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 22,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_engineer = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'E','n','g','i', 'n','e','e','r'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 32,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_default = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'D','e','f','a','u','l','t'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 42,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};


view_rectangle_t rec_view_exit = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'E','x','i','t'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 52,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_back = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'B','a','c','k'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 52,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};


/*----------[[[OBJECT]]]------------*/

view_screen_t scr_main_setting = {
	&dyn_view_main_tilde_setting,
	&rec_view_time,
	&rec_view_air,
	&rec_view_engineer,
	&rec_view_default,
	&rec_view_exit,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

/**
 ******************************************************************************
 * objects TIME SCREEN SETTING
 *
 ******************************************************************************
 */

/*----------[[[ITERM]]]------------*/
view_dynamic_t dyn_view_time_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_time_tilde_setting
};

view_rectangle_t rec_view_time_setting_clock = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 20,
	.y		= 16,
	.width	= 88,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_time_setting_date = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 20,
	.y		= 32,
	.width	= 88,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_setting_back = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'B','a','c','k'},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 20,
	.y		= 48,
	.width	= 88,
	.height = 14,

	.border_width = 0
};

/*----------[[[OBJECT]]]------------*/

view_screen_t scr_time_setting = {
	&dyn_view_time_tilde_setting,
	&rec_view_time_setting_clock,
	&rec_view_time_setting_date,
	&rec_view_setting_back,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

/**
 ******************************************************************************
 * objects AIR SCREEN SETTING
 *
 ******************************************************************************
 */
/*----------[[[ITERM]]]------------*/
view_dynamic_t dyn_view_air_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_air_tilde_setting
};

view_dynamic_t dyn_view_air_total_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_air_total_tilde_setting
};

view_dynamic_t dyn_view_air_timer_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_air_timer_tilde_setting
};

view_dynamic_t dyn_view_air_temp_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_air_temp_tilde_setting
};

view_dynamic_t dyn_view_air_temp_aircond_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_air_temp_aircond_tilde_setting
};

view_dynamic_t dyn_view_air_temp_fan_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_air_temp_fan_tilde_setting
};

view_rectangle_t rec_view_air_total = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'T','o','t','a','l'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 12,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_air_timer = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'T','i','m','e', 'r'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 22,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0

};

view_rectangle_t rec_view_air_temp = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'T','e','m','p','e','r','a','t','u','r','e'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 32,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_air_total_aircond = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 30,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_air_total_aircond_active = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 75,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_air_setting_parameter = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 20,
	.y		= 20,
	.width	= 88,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_air_temp_aircond = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'A','i','r',' ','c','o','n','d','i','t','i','o','n','e','r'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 14,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 12,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_air_temp_fan = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'F','a','n',' ','B','a','c','k','u','p'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 14,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 22,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_air_setting_back = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'B','a','c','k'},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 20,
	.y		= 40,
	.width	= 88,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_air_temp_active_low = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 10,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_air_temp_active_high = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 35,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_air_temp_backup_low = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 70,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_air_temp_backup_high = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 95,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_air_temp_fan_low = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 30,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_air_temp_fan_high = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 75,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};


/*----------[[[OBJECT]]]------------*/

view_screen_t scr_air_setting = {
	&dyn_view_air_tilde_setting,
	&rec_view_air_total,
	&rec_view_air_timer,
	&rec_view_air_temp,
	&rec_view_back,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_air_total_setting = {
	&dyn_view_air_total_tilde_setting,
	&rec_view_air_total_aircond,
	&rec_view_air_total_aircond_active,
	&rec_view_setting_back,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_air_timer_setting = {
	&dyn_view_air_timer_tilde_setting,
	&rec_view_air_setting_parameter,
	&rec_view_air_setting_back,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_air_temp_setting = {
	&dyn_view_air_temp_tilde_setting,
	&rec_view_air_temp_aircond,
	&rec_view_air_temp_fan,
	&rec_view_back,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_air_temp_aircond_setting = {
	&dyn_view_air_temp_aircond_tilde_setting,
	&rec_view_air_temp_active_low,
	&rec_view_air_temp_active_high,
	&rec_view_air_temp_backup_low,
	&rec_view_air_temp_backup_high,
	&rec_view_setting_back,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_air_temp_fan_setting = {
	&dyn_view_air_temp_fan_tilde_setting,
	&rec_view_air_temp_fan_low,
	&rec_view_air_temp_fan_high,
	&rec_view_setting_back,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

/**
 ******************************************************************************
 * objects ENGINEER SCREEN SETTING
 *
 ******************************************************************************
 */
/*----------[[[ITERM]]]------------*/
view_dynamic_t dyn_view_engineer_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_engineer_tilde_setting
};

view_dynamic_t dyn_view_engineer_network_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_engineer_network_tilde_settings
};

view_dynamic_t dyn_view_engineer_change_mode = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_engineer_change_mode_tilde_settings
};

view_dynamic_t dyn_view_engineer_control_output_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_engineer_control_output_tilde_settings
};

view_dynamic_t dyn_view_engineer_control_aircond_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_engineer_control_aircond_tilde_settings
};

view_dynamic_t dyn_view_engineer_control_general_output_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_engineer_control_general_output_tilde_settings
};

view_dynamic_t dyn_view_engineer_calib_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_engineer_calib_settings
};

view_dynamic_t dyn_view_engineer_calib_current_air_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_engineer_calib_current_air_setting
};

view_dynamic_t dyn_view_engineer_calib_temp_hum_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_engineer_calib_temp_hum_setting
};

view_rectangle_t rec_view_network_parameter = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'N','e','t','w','o','r','k'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 12,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0

};

view_rectangle_t rec_view_change_mode = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'C','h','a','n','g','e',' ','m','o','d','e'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 22,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_control_output = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'C','o','n','t','r','o','l',' ','o','u','t','p','u','t'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 32,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_calib_parameter = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'C','a','l','i','b','r','a','t','i','o','n'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 42,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0

};

view_rectangle_t rec_view_network_node_chanel_parameter = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 12,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 12,
	.width	= DISPLAY_WIDTH,
	.height = 12,

	.border_width = 0

};

view_rectangle_t rec_view_network_node_addr_parameter = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 12,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 24,
	.width	= DISPLAY_WIDTH,
	.height = 12,

	.border_width = 0

};

view_rectangle_t rec_view_network_server_addr_parameter = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 12,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 36,
	.width	= DISPLAY_WIDTH,
	.height = 12,

	.border_width = 0
};

view_rectangle_t rec_view_engineer_change_mode = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 7,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 20,
	.y		= 20,
	.width	= 88,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_control_air_1 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 8,
	.y		= 30,
	.width	= 24,
	.height = 14,

	.border_width = 0
};


view_rectangle_t rec_control_air_2 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 38,
	.y		= 30,
	.width	= 24,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_control_air_3 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 68,
	.y		= 30,
	.width	= 24,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_control_air_4 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 98,
	.y		= 30,
	.width	= 24,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_control_general_output_1 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 8,
	.y		= 30,
	.width	= 24,
	.height = 14,

	.border_width = 0
};


view_rectangle_t rec_control_general_output_2 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 38,
	.y		= 30,
	.width	= 24,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_control_general_output_3 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 68,
	.y		= 30,
	.width	= 24,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_control_general_output_4 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 98,
	.y		= 30,
	.width	= 24,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_control_aircond = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'A','i','r',' ','C','o','n','d','i','t','i','o','n','e','r'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 14,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 12,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_control_gpo = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'G','e','n','e','r','a','l',' ','o','u','t','p','u','t'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 14,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 22,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_calib_current_air = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'C','u','r','r','e','n','t',' ','a','i','r'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 14,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 12,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_calib_temp_hum = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'T','e','m','p',' ','-',' ','H','u','m'},
	.align_text		= ITEM_TYPE_ALINE_LEFT,
	.font_size		= 1,

	.focus_cursor	= 14,
	.focus_size		= 3,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 0,
	.y		= 22,
	.width	= DISPLAY_WIDTH,
	.height = 10,

	.border_width = 0
};

view_rectangle_t rec_view_calib_current_air_1 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 4,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 2,
	.y		= 30,
	.width	= 28,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_calib_current_air_2 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 4,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 34,
	.y		= 30,
	.width	= 28,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_calib_current_air_3 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 4,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 66,
	.y		= 30,
	.width	= 28,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_calib_current_air_4 = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 4,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 98,
	.y		= 30,
	.width	= 28,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_calib_temp_operation = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 1,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 10,
	.y		= 32,
	.width	= 14,
	.height = 14,

	.border_width = 0
};


view_rectangle_t rec_view_calib_temp_value = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 30,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_calib_hum_operation= {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 1,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 70,
	.y		= 32,
	.width	= 14,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_calib_hum_value = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_NONE_OUTLINE,

	.x		= 90,
	.y		= 32,
	.width	= 18,
	.height = 14,

	.border_width = 0
};
/*----------[[[OBJECT]]]------------*/

view_screen_t scr_engineer_setting = {
	&dyn_view_engineer_tilde_setting,
	&rec_view_network_parameter,
	&rec_view_change_mode,
	&rec_view_control_output,
	&rec_view_calib_parameter,
	&rec_view_back,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_engineer_network_setting = {
	&dyn_view_engineer_network_tilde_setting,
	&rec_view_network_node_chanel_parameter,
	&rec_view_network_node_addr_parameter,
	&rec_view_network_server_addr_parameter,
	&rec_view_back,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_engineer_change_mode = {
	&dyn_view_engineer_change_mode,
	&rec_view_engineer_change_mode,
	&rec_view_setting_back,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_engineer_control_output_setting = {
	&dyn_view_engineer_control_output_setting,
	&rec_view_control_aircond,
	&rec_view_control_gpo,
	&rec_view_back,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_engineer_control_aircond_setting = {
	&dyn_view_engineer_control_aircond_setting,
	&rec_view_setting_back,
	&rec_control_air_1,
	&rec_control_air_2,
	&rec_control_air_3,
	&rec_control_air_4,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_engineer_control_general_output_setting = {
	&dyn_view_engineer_control_general_output_setting,
	&rec_view_setting_back,
	&rec_control_general_output_1,
	&rec_control_general_output_2,
	&rec_control_general_output_3,
	&rec_control_general_output_4,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};


view_screen_t scr_engineer_calib_setting = {
	&dyn_view_engineer_calib_setting,
	&rec_view_calib_current_air,
	&rec_view_calib_temp_hum,
	&rec_view_back,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_engineer_calib_current_air_setting = {
	&dyn_view_engineer_calib_current_air_setting,
	&rec_view_setting_back,
	&rec_view_calib_current_air_1,
	&rec_view_calib_current_air_2,
	&rec_view_calib_current_air_3,
	&rec_view_calib_current_air_4,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

view_screen_t scr_engineer_calib_temp_hum_setting = {
	&dyn_view_engineer_calib_temp_hum_setting,
	&rec_view_calib_temp_operation,
	&rec_view_calib_temp_value,
	&rec_view_calib_hum_operation,
	&rec_view_calib_hum_value,
	&rec_view_setting_back,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};

/**
 ******************************************************************************
 * objects DEFAULT SCREEN SETTING
 *
 ******************************************************************************
 */
/*----------[[[ITERM]]]------------*/
view_dynamic_t dyn_view_default_tilde_setting = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_default_tilde_setting
};


view_dynamic_t dyn_view_default_setting_ok = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_default_setting_ok
};


view_dynamic_t dyn_view_default_setting_fail = {
	{
		.item_type = ITEM_TYPE_DYNAMIC,
	},
	view_scr_default_setting_fail
};

view_rectangle_t rec_view_default_no = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'N'},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 80,
	.y		= 46,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

view_rectangle_t rec_view_default_yes = {
	{
		.item_type = ITEM_TYPE_RECTANGLE,
	},
	.text			= {'Y'},
	.align_text		= ITEM_TYPE_ALINE_CENTER,
	.font_size		= 1,

	.focus_cursor	= 0,
	.focus_size		= 2,

	.type			= BACK_GND_STYLE_OUTLINE,

	.x		= 20,
	.y		= 46,
	.width	= 18,
	.height = 14,

	.border_width = 0
};

/*----------[[[OBJECT]]]------------*/

view_screen_t scr_default_setting = {
	&dyn_view_default_tilde_setting,
	&rec_view_default_no,
	&rec_view_default_yes,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 1,
	.focus_item_before = 1,
	.focus_item_after = 1,
};


view_screen_t scr_default_ok_setting = {
	&dyn_view_default_setting_ok,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 0,
	.focus_item_before = 0,
	.focus_item_after = 0,
};


view_screen_t scr_default_fail_setting = {
	&dyn_view_default_setting_fail,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,
	ITEM_NULL,

	.focus_item = 0,
	.focus_item_before = 0,
	.focus_item_after = 0,
};


/**
 ******************************************************************************
 * render function for dynamic object
 *
 ******************************************************************************
 */

void view_scr_tilde(const char* s) {
	view_render.setDefaultForegroundColor();
	view_render.setFont(u8g_font_5x7);
	view_render.drawStr(0, 7,s);
	view_render.drawLine(0, 10, DISPLAY_WIDTH, 10);
}

void view_scr_main() {
	char str[15];

	view_render.setDefaultForegroundColor();
	view_render.setFont(u8g_font_timR10);
	xsprintf(str,"%02d : %02d%c", rtc_time.hours, rtc_time.minutes, '\0');
	view_render.drawStr(13, 15, str);

	view_render.drawRFrame(0, 20, 64, 42, 5);
	view_render.drawRFrame(66, 0, 60, 62, 5);

	view_render.setFont(u8g_font_timR08);
	view_render.drawStr(8, 32, "AIRCOND");

	view_render.drawBox(4, 40, 10, 10);
	view_render.drawBox(19, 40, 10, 10);
	view_render.drawBox(34, 40, 10, 10);
	view_render.drawBox(49, 40, 10, 10);

	view_render.setFont(u8g_font_5x7);
	view_render.setDefaultBackgroundColor();

	view_render.setFont(u8g_font_5x7);
	view_render.setDefaultForegroundColor();
}

void view_scr_main_tilde_setting() {
	view_scr_tilde("Menu setting");
}

void view_scr_time_tilde_setting() {
	view_scr_tilde("Time setting");
}

void view_scr_air_tilde_setting() {
	view_scr_tilde("Air setting");
}

void view_scr_air_total_tilde_setting() {
	view_scr_tilde("Total air setting");

	view_render.drawStr(26, 30,"Total");
	view_render.drawStr(71, 30,"Active");
}

void view_scr_air_timer_tilde_setting() {
	view_scr_tilde("Timer air setting");
}

void view_scr_air_temp_tilde_setting() {
	view_scr_tilde("Temperature setting");
}

void view_scr_air_temp_aircond_tilde_setting() {
	view_scr_tilde("Temperature air setting");

	view_render.drawLine(62, 10, 62, 46);

	view_render.drawStr(20, 20,"Active");
	view_render.drawStr(13, 30,"Low");
	view_render.drawStr(35, 30,"High");

	view_render.drawStr(78, 20,"Backup");
	view_render.drawStr(72, 30,"Low");
	view_render.drawStr(95, 30,"High");
}

void view_scr_air_temp_fan_tilde_setting() {
	view_scr_tilde("Temperature fan setting");

	view_render.drawStr(32, 30,"Low");
	view_render.drawStr(75, 30,"High");
}

void view_scr_engineer_tilde_setting() {
	view_scr_tilde("Engineer setting");
}

void view_scr_default_tilde_setting() {
	view_scr_tilde("Default setting");

	view_render.drawStr(30, 20,"Do you want to");
	view_render.drawStr(15, 30,"use default setting");
}

void view_scr_default_setting_ok() {
	view_scr_tilde("Default setting");

	view_render.drawStr(0, 20,"Setting default parameter");
	view_render.drawStr(45, 45,"SUCCESS");
}

void view_scr_default_setting_fail() {
	view_scr_tilde("Default setting");

	view_render.drawStr(0, 20,"Setting default parameter");
	view_render.drawStr(45, 45,"FAILED");
}

void view_scr_setting_busy() {
	view_render.setDefaultForegroundColor();
	view_render.setFont(u8g_font_5x7);
	view_render.drawStr(30, 10,"System is busy");
	view_render.drawStr(20, 30,"please setting later");
}

void view_scr_firmware_update() {
	view_render.setDefaultForegroundColor();
	view_render.setFont(u8g_font_5x7);
	view_render.drawStr(25, 20,"FIRMWARE UPDATING");
	view_render.drawStr(27, 40,"(please waiting)");
	view_render.drawStr(60, 50,"...");
}

void view_scr_main_current_aircond() {
	char str[15];

	view_scr_tilde("Current CT sensor    (mA)");
}

void view_scr_main_parameter_setting() {
	char str[25];

	view_scr_tilde("App parameter");
}

void view_scr_main_network_gateway() {
}

void view_scr_engineer_control_output_tilde_settings() {
	view_scr_tilde("Control output");
}

void view_scr_engineer_control_aircond_tilde_settings() {
	char str[15];

	view_scr_tilde("Control air-conditioner");
}

void view_scr_engineer_control_general_output_tilde_settings() {
	char str[15];

	view_scr_tilde("Control general output");

}

void view_scr_engineer_network_tilde_settings() {
	view_scr_tilde("Network parameter");
}

void view_scr_engineer_change_mode_tilde_settings() {
	view_scr_tilde("Change mode");
}

void view_scr_settings_init_data_start() {
	view_render.setDefaultForegroundColor();
	view_render.setFont(u8g_font_5x7);
	view_render.drawBox(10, 36, 105, 20);

	view_render.setDefaultBackgroundColor();
	view_render.drawStr(30, 42,"waitting...");
}

void view_scr_engineer_calib_settings() {
	view_scr_tilde("Calibration mode");
}

void view_engineer_calib_current_air_setting() {
	char str[15];

	view_scr_tilde("Calib current air");
}

void view_engineer_calib_temp_hum_setting() {
	view_scr_tilde("Calib temp-hum");

	view_render.drawLine(62, 10, 62, 46);

	view_render.drawStr(20, 25,"Temp");
	view_render.drawStr(85, 25,"Hum");
}
