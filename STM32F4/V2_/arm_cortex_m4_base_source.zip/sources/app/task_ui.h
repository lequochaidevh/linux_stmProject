#ifndef __TASK_UI_H__
#define __TASK_UI_H__

#include <stdint.h>

#include "ak.h"
#include "fsm.h"

#include "screen_manager.h"

#include "button.h"

#define BUTTON_MODE_ID					(0x01)
#define BUTTON_UP_ID					(0x02)
#define BUTTON_DOWN_ID					(0x03)

#define TEMP_AIR_ACTIVE_LOW_MAX			(28)
#define TEMP_AIR_ACTIVE_LOW_MIN			(15)
#define TEMP_AIR_ACTIVE_HIGH_MAX		(32)
#define TEMP_AIR_ACTIVE_HIGH_MIN		(20)

#define TEMP_AIR_BACKUP_LOW_MAX			(30)
#define TEMP_AIR_BACKUP_LOW_MIN			(17)
#define TEMP_AIR_BACKUP_HIGH_MAX		(34)
#define TEMP_AIR_BACKUP_HIGH_MIN		(22)

#define TEMP_FAN_BACKUP_LOW_MAX			(35)
#define TEMP_FAN_BACKUP_LOW_MIN			(25)
#define TEMP_FAN_BACKUP_HIGH_MAX		(37)
#define TEMP_FAN_BACKUP_HIGH_MIN		(27)

#define MAX_CALIB_TEMP					(10)
#define MAX_CALIB_HUM					(30)

extern fsm_t fsm_ui;

extern void ui_state_display_on(ak_msg_t* msg);
extern void ui_state_display_off(ak_msg_t* msg);

extern scr_mng_t screen_ui;

extern button_t btn_mode;
extern button_t btn_up;
extern button_t btn_down;

extern void btn_mode_callback(void*);
extern void btn_up_callback(void*);
extern void btn_down_callback(void*);

/*****************************************************************************/
/* main screen
 */
/*****************************************************************************/
extern void ctrl_scr_main(ak_msg_t* msg);
extern void ctrl_scr_main_current_aircond(ak_msg_t* msg);
extern void ctrl_scr_main_app_setting(ak_msg_t* msg);
extern void ctrl_scr_main_network_gateway(ak_msg_t* msg);
extern void ctrl_scr_settings_system_busy(ak_msg_t* msg);
extern void ctrl_scr_settings_firmware_update(ak_msg_t* msg);

/*****************************************************************************/
/* MAIN SETTING screen
 */
/*****************************************************************************/
extern void ctrl_scr_main_setting(ak_msg_t* msg);

/*****************************************************************************/
/* TIME SETTING screen
 */
/*****************************************************************************/
extern void ctrl_scr_time_setting(ak_msg_t* msg);

/*****************************************************************************/
/* AIR SETTING screen
 */
/*****************************************************************************/
extern void ctrl_scr_air_setting(ak_msg_t* msg);
extern void ctrl_scr_air_total_setting(ak_msg_t* msg);
extern void ctrl_scr_air_timer_setting(ak_msg_t* msg);
extern void ctrl_scr_air_temp_setting(ak_msg_t* msg);
extern void ctrl_scr_air_temp_aircond_setting(ak_msg_t* msg);
extern void ctrl_scr_air_temp_fan_setting(ak_msg_t* msg);

/*****************************************************************************/
/* ENGINEER SETTING screen
 */
/*****************************************************************************/
extern void ctrl_scr_engineer_setting(ak_msg_t* msg);
extern void ctrl_scr_engineer_network_setting(ak_msg_t* msg);
extern void ctrl_scr_engineer_change_mode(ak_msg_t* msg);

extern void ctrl_scr_engineer_control_output_setting(ak_msg_t* msg);
extern void ctrl_scr_engineer_control_aircond_setting(ak_msg_t* msg);
extern void ctrl_scr_engineer_control_general_output_setting(ak_msg_t* msg);

extern void ctrl_scr_engineer_calib_setting(ak_msg_t* msg);
extern void ctrl_scr_engineer_calib_current_air_setting(ak_msg_t* msg);
extern void ctrl_scr_engineer_calib_temp_hum_setting(ak_msg_t* msg);
extern void ctrl_scr_engineer_calib_hum_setting(ak_msg_t* msg);

/*****************************************************************************/
/* DEFAULT SETTING screen
 */
/*****************************************************************************/
extern void ctrl_scr_default_setting(ak_msg_t* msg);
extern void ctrl_scr_default_ok_setting(ak_msg_t* msg);
extern void ctrl_scr_default_fail_setting(ak_msg_t* msg);

#endif //__TASK_UI_H__
