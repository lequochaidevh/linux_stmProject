#ifndef __TASK_SM_H__
#define __TASK_SM_H__

#include <stdint.h>

#include "ak.h"
#include "fsm.h"
#include "tsm.h"

#include "app_data.h"

#include "rtc.h"
#include "flash.h"

enum {
	SL_SM_IDLE,
	SL_SM_AUTO_CONTROL,
	SL_SM_MANUAL_CONTROL,
	SL_SM_SETTING,
	SL_SM_FIRMWARE_UPDATE,
	SL_SM_CRITICAL
};

extern tsm_t* tsm_sl_sm_table[];
extern tsm_tbl_t tsm_sl_sm;

extern rtc_t rtc;
extern rtc_time_t rtc_time;

#endif //__TASK_SM_H__
