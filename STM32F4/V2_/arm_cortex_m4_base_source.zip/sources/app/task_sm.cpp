#include "fsm.h"
#include "tsm.h"
#include "port.h"
#include "message.h"
#include "timer.h"

#include "app.h"
#include "app_dbg.h"
#include "app_if.h"
#include "app_flash.h"

#include "task_list.h"
#include "task_list_if.h"
#include "task_sm.h"
#include "task_if.h"

#include "utils.h"

#include "sys_dbg.h"

enum {
	NO_CHANGE_AIR_COND,
	THRESHOLD_CHANGE_AIR_COND,
	CHANGE_AIR_COND,
	AIR_COND_CTRL_RETRY_MAX
};

tsm_tbl_t tsm_sl_sm;

rtc_t rtc;
rtc_time_t rtc_time;

static uint8_t output_power_ctrl_retry_time = 0;
static uint8_t air_cond_detect_error_time = 0;
static uint8_t air_cond_detect_error_counter = 0;

static uint8_t air_cond_backup_rate_active = 0;

static void sl_sm_req_auto_control_output_power(ak_msg_t* msg);

static void sl_sm_req_output_power_status(ak_msg_t* msg);
static void sl_sm_create_output_power_status(ak_msg_t* msg);

static void sl_sm_req_air_cond_status(ak_msg_t* msg);
static void sl_sm_req_control_aircond(ak_msg_t* msg);
static void sl_sm_create_air_cond_status(ak_msg_t* msg);

static void sl_sm_req_fan_status(ak_msg_t* msg);
static void sl_sm_req_control_fan(ak_msg_t* msg);
static void sl_sm_create_fan_status(ak_msg_t* msg);

static void sl_sm_req_sensor_modbus_slave_info(ak_msg_t* msg);
static void sl_sm_res_sensor_modbus_slave_info(ak_msg_t* msg);

static void sl_sm_res_setting_ok(ak_msg_t* msg);
static void sl_sm_res_setting_busy(ak_msg_t* msg);
static void sl_sm_req_firmware_update_start(ak_msg_t* msg);
static void sl_sm_req_firmware_update_timeout(ak_msg_t* msg);
static void sl_sm_req_firmware_update_complete(ak_msg_t* msg);
static void sl_sm_req_firmware_update_error(ak_msg_t* msg);

static void sl_sm_req_tran_state(ak_msg_t* msg);

static void sl_mt_sm_res_control_mode(ak_msg_t*);

static void sl_mt_sm_res_air_cond_manual_control();
static void sl_mt_sm_res_fan_manual_control();

static void sl_sm_req_checking_key_door(ak_msg_t* msg);
static void sl_sm_res_checking_key_door(ak_msg_t* msg);
static void sl_sm_req_control_door(ak_msg_t* msg);
static void sl_sm_res_control_door(ak_msg_t* msg);

static void sl_sm_res_control_auto_ok();
static void sl_sm_res_control_auto_fail();

static void sl_sm_req_manual_control_output_power(ak_msg_t* msg);
static void sl_sm_req_critical_control_output_power(ak_msg_t* msg);

static void sl_sm_modbus_baudrate_setting_req(ak_msg_t* msg);

void task_sm(ak_msg_t* msg) {
	tsm_dispatch(&tsm_sl_sm, msg);
}

tsm_t sl_sm_idle[] = {
	{	SL_SM_AUTO_CONTROL_OUTPUT_POWER_REQ		,	SL_SM_IDLE				,	sl_sm_req_auto_control_output_power			},
	{	SL_SM_OUTPUT_POWER_STATUS_REQ			,	SL_SM_AUTO_CONTROL		,	sl_sm_req_output_power_status				},
	{	SL_SM_AIR_COND_STATUS_REQ				,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_FAN_STATUS_REQ					,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_OUTPUT_POWER_STATUS_RES	,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_AIR_COND_STATUS_RES		,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_FAN_STATUS_RES				,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_TEMPERATURE_STATUS_RES		,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_REQ		,	SL_SM_IDLE				,	sl_sm_req_sensor_modbus_slave_info			},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_RES		,	SL_SM_IDLE				,	sl_sm_res_sensor_modbus_slave_info			},
	{	SL_SM_FIRMWARE_UPDATE_REQ				,	SL_SM_FIRMWARE_UPDATE	,	sl_sm_req_firmware_update_start				},
	{	SL_SM_FIRMWARE_UPDATE_TIMEOUT_REQ		,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_COMPLETE_REQ		,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_ERROR_REQ			,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_UI_SETTING_START_REQ				,	SL_SM_SETTING			,	sl_sm_res_setting_ok						},
	{	SL_SM_UI_SETTING_END_REQ				,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_MODE_REQ					,	SL_SM_IDLE				,	sl_mt_sm_res_control_mode					},
	{	SL_SM_CONTROL_AIR_COND_REQ				,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_FAN_REQ					,	SL_SM_IDLE				,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_DOOR_REQ					,	SL_SM_IDLE				,	sl_sm_req_control_door						},
	{	SL_SM_CONTROL_DOOR_RES					,	SL_SM_IDLE				,	sl_sm_res_control_door						},
	{	SL_SM_CHECKING_KEY_DOOR_REQ				,	SL_SM_IDLE				,	sl_sm_req_checking_key_door					},
	{	SL_SM_CHECKING_KEY_DOOR_RES				,	SL_SM_IDLE				,	sl_sm_res_checking_key_door					},
	{	SL_SM_MODBUS_BAUDRATE_SETTING_REQ		,	SL_SM_IDLE				,	sl_sm_modbus_baudrate_setting_req			},
};

tsm_t sl_sm_auto_control[] = {
	{	SL_SM_AUTO_CONTROL_OUTPUT_POWER_REQ		,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_OUTPUT_POWER_STATUS_REQ			,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_AIR_COND_STATUS_REQ				,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_FAN_STATUS_REQ					,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_OUTPUT_POWER_STATUS_RES	,	SL_SM_AUTO_CONTROL		,	sl_sm_create_output_power_status			},
	{	SL_SM_SENSOR_AIR_COND_STATUS_RES		,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_FAN_STATUS_RES				,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_TEMPERATURE_STATUS_RES		,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_REQ		,	SL_SM_AUTO_CONTROL		,	sl_sm_req_sensor_modbus_slave_info			},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_RES		,	SL_SM_AUTO_CONTROL		,	sl_sm_res_sensor_modbus_slave_info			},
	{	SL_SM_FIRMWARE_UPDATE_REQ				,	SL_SM_FIRMWARE_UPDATE	,	sl_sm_req_firmware_update_start				},
	{	SL_SM_FIRMWARE_UPDATE_TIMEOUT_REQ		,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_COMPLETE_REQ		,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_ERROR_REQ			,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_UI_SETTING_START_REQ				,	SL_SM_AUTO_CONTROL		,	sl_sm_res_setting_busy						},
	{	SL_SM_UI_SETTING_END_REQ				,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_MODE_REQ					,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_AIR_COND_REQ				,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_FAN_REQ					,	SL_SM_AUTO_CONTROL		,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_DOOR_REQ					,	SL_SM_AUTO_CONTROL		,	sl_sm_req_control_door						},
	{	SL_SM_CONTROL_DOOR_RES					,	SL_SM_AUTO_CONTROL		,	sl_sm_res_control_door						},
	{	SL_SM_CHECKING_KEY_DOOR_REQ				,	SL_SM_AUTO_CONTROL		,	sl_sm_req_checking_key_door					},
	{	SL_SM_CHECKING_KEY_DOOR_RES				,	SL_SM_AUTO_CONTROL		,	sl_sm_res_checking_key_door					},
	{	SL_SM_MODBUS_BAUDRATE_SETTING_REQ		,	SL_SM_AUTO_CONTROL		,	sl_sm_modbus_baudrate_setting_req			},
};

tsm_t sl_sm_manual_control[] = {
	{	SL_SM_AUTO_CONTROL_OUTPUT_POWER_REQ		,	SL_SM_MANUAL_CONTROL	,	sl_sm_req_manual_control_output_power		},
	{	SL_SM_OUTPUT_POWER_STATUS_REQ			,	SL_SM_MANUAL_CONTROL	,	TSM_FUNCTION_NULL							},
	{	SL_SM_AIR_COND_STATUS_REQ				,	SL_SM_MANUAL_CONTROL	,	sl_sm_req_air_cond_status					},
	{	SL_SM_FAN_STATUS_REQ					,	SL_SM_MANUAL_CONTROL	,	sl_sm_req_fan_status						},
	{	SL_SM_SENSOR_OUTPUT_POWER_STATUS_RES	,	SL_SM_MANUAL_CONTROL	,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_AIR_COND_STATUS_RES		,	SL_SM_MANUAL_CONTROL	,	sl_sm_create_air_cond_status				},
	{	SL_SM_SENSOR_FAN_STATUS_RES				,	SL_SM_MANUAL_CONTROL	,	sl_sm_create_fan_status						},
	{	SL_SM_SENSOR_TEMPERATURE_STATUS_RES		,	SL_SM_MANUAL_CONTROL	,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_REQ		,	SL_SM_AUTO_CONTROL		,	sl_sm_req_sensor_modbus_slave_info			},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_RES		,	SL_SM_AUTO_CONTROL		,	sl_sm_res_sensor_modbus_slave_info			},
	{	SL_SM_FIRMWARE_UPDATE_REQ				,	SL_SM_FIRMWARE_UPDATE	,	sl_sm_req_firmware_update_start				},
	{	SL_SM_FIRMWARE_UPDATE_TIMEOUT_REQ		,	SL_SM_MANUAL_CONTROL	,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_COMPLETE_REQ		,	SL_SM_MANUAL_CONTROL	,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_ERROR_REQ			,	SL_SM_MANUAL_CONTROL	,	TSM_FUNCTION_NULL							},
	{	SL_SM_UI_SETTING_START_REQ				,	SL_SM_SETTING			,	sl_sm_res_setting_ok						},
	{	SL_SM_UI_SETTING_END_REQ				,	SL_SM_MANUAL_CONTROL	,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_MODE_REQ					,	SL_SM_MANUAL_CONTROL	,	sl_mt_sm_res_control_mode					},
	{	SL_SM_CONTROL_AIR_COND_REQ				,	SL_SM_MANUAL_CONTROL	,	sl_sm_req_control_aircond					},
	{	SL_SM_CONTROL_FAN_REQ					,	SL_SM_MANUAL_CONTROL	,	sl_sm_req_control_fan						},
	{	SL_SM_CONTROL_DOOR_REQ					,	SL_SM_MANUAL_CONTROL	,	sl_sm_req_control_door						},
	{	SL_SM_CONTROL_DOOR_RES					,	SL_SM_MANUAL_CONTROL	,	sl_sm_res_control_door						},
	{	SL_SM_CHECKING_KEY_DOOR_REQ				,	SL_SM_MANUAL_CONTROL	,	sl_sm_req_checking_key_door					},
	{	SL_SM_CHECKING_KEY_DOOR_RES				,	SL_SM_MANUAL_CONTROL	,	sl_sm_res_checking_key_door					},
	{	SL_SM_MODBUS_BAUDRATE_SETTING_REQ		,	SL_SM_MANUAL_CONTROL	,	sl_sm_modbus_baudrate_setting_req			},
};

tsm_t sl_sm_setting[] = {
	{	SL_SM_AUTO_CONTROL_OUTPUT_POWER_REQ		,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_OUTPUT_POWER_STATUS_REQ			,	SL_SM_MANUAL_CONTROL	,	TSM_FUNCTION_NULL							},
	{	SL_SM_AIR_COND_STATUS_REQ				,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_FAN_STATUS_REQ					,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_OUTPUT_POWER_STATUS_RES	,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_AIR_COND_STATUS_RES		,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_FAN_STATUS_RES				,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_TEMPERATURE_STATUS_RES		,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_REQ		,	SL_SM_SETTING			,	sl_sm_req_sensor_modbus_slave_info			},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_RES		,	SL_SM_SETTING			,	sl_sm_res_sensor_modbus_slave_info			},
	{	SL_SM_FIRMWARE_UPDATE_REQ				,	SL_SM_FIRMWARE_UPDATE	,	sl_sm_req_firmware_update_start				},
	{	SL_SM_FIRMWARE_UPDATE_TIMEOUT_REQ		,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_COMPLETE_REQ		,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_ERROR_REQ			,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_UI_SETTING_START_REQ				,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_UI_SETTING_END_REQ				,	SL_SM_SETTING			,	sl_sm_req_tran_state						},
	{	SL_SM_CONTROL_MODE_REQ					,	SL_SM_SETTING			,	sl_mt_sm_res_control_mode					},
	{	SL_SM_CONTROL_AIR_COND_REQ				,	SL_SM_SETTING			,	sl_sm_req_control_aircond					},
	{	SL_SM_CONTROL_FAN_REQ					,	SL_SM_SETTING			,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_DOOR_REQ					,	SL_SM_SETTING			,	sl_sm_req_control_door						},
	{	SL_SM_CONTROL_DOOR_RES					,	SL_SM_SETTING			,	sl_sm_res_control_door						},
	{	SL_SM_CHECKING_KEY_DOOR_REQ				,	SL_SM_SETTING			,	sl_sm_req_checking_key_door					},
	{	SL_SM_CHECKING_KEY_DOOR_RES				,	SL_SM_SETTING			,	sl_sm_res_checking_key_door					},
	{	SL_SM_MODBUS_BAUDRATE_SETTING_REQ		,	SL_SM_SETTING			,	sl_sm_modbus_baudrate_setting_req			},
};

tsm_t sl_sm_firmware_update[] = {
	{	SL_SM_AUTO_CONTROL_OUTPUT_POWER_REQ		,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_OUTPUT_POWER_STATUS_REQ			,	SL_SM_MANUAL_CONTROL	,	TSM_FUNCTION_NULL							},
	{	SL_SM_AIR_COND_STATUS_REQ				,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_FAN_STATUS_REQ					,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_OUTPUT_POWER_STATUS_RES	,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_AIR_COND_STATUS_RES		,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_FAN_STATUS_RES				,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_TEMPERATURE_STATUS_RES		,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_REQ		,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_RES		,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_REQ				,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_TIMEOUT_REQ		,	SL_SM_FIRMWARE_UPDATE	,	sl_sm_req_firmware_update_timeout			},
	{	SL_SM_FIRMWARE_UPDATE_COMPLETE_REQ		,	SL_SM_FIRMWARE_UPDATE	,	sl_sm_req_firmware_update_complete			},
	{	SL_SM_FIRMWARE_UPDATE_ERROR_REQ			,	SL_SM_FIRMWARE_UPDATE	,	sl_sm_req_firmware_update_error				},
	{	SL_SM_UI_SETTING_START_REQ				,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_UI_SETTING_END_REQ				,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_MODE_REQ					,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_AIR_COND_REQ				,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_FAN_REQ					,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_DOOR_REQ					,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_DOOR_RES					,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_CHECKING_KEY_DOOR_REQ				,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_CHECKING_KEY_DOOR_RES				,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
	{	SL_SM_MODBUS_BAUDRATE_SETTING_REQ		,	SL_SM_FIRMWARE_UPDATE	,	TSM_FUNCTION_NULL							},
};

tsm_t sl_sm_critical[] = {
	{	SL_SM_AUTO_CONTROL_OUTPUT_POWER_REQ		,	SL_SM_CRITICAL			,	sl_sm_req_critical_control_output_power		},
	{	SL_SM_OUTPUT_POWER_STATUS_REQ			,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_AIR_COND_STATUS_REQ				,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_FAN_STATUS_REQ					,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_OUTPUT_POWER_STATUS_RES	,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_AIR_COND_STATUS_RES		,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_FAN_STATUS_RES				,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_TEMPERATURE_STATUS_RES		,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_REQ		,	SL_SM_CRITICAL			,	sl_sm_req_sensor_modbus_slave_info			},
	{	SL_SM_SENSOR_MODBUS_SLAVE_INFO_RES		,	SL_SM_CRITICAL			,	sl_sm_res_sensor_modbus_slave_info			},
	{	SL_SM_FIRMWARE_UPDATE_REQ				,	SL_SM_FIRMWARE_UPDATE	,	sl_sm_req_firmware_update_start				},
	{	SL_SM_FIRMWARE_UPDATE_TIMEOUT_REQ		,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_COMPLETE_REQ		,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_FIRMWARE_UPDATE_ERROR_REQ			,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_UI_SETTING_START_REQ				,	SL_SM_SETTING			,	sl_sm_res_setting_ok						},
	{	SL_SM_UI_SETTING_END_REQ				,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_MODE_REQ					,	SL_SM_CRITICAL			,	sl_mt_sm_res_control_mode					},
	{	SL_SM_CONTROL_AIR_COND_REQ				,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_FAN_REQ					,	SL_SM_CRITICAL			,	TSM_FUNCTION_NULL							},
	{	SL_SM_CONTROL_DOOR_REQ					,	SL_SM_CRITICAL			,	sl_sm_req_control_door						},
	{	SL_SM_CONTROL_DOOR_RES					,	SL_SM_CRITICAL			,	sl_sm_res_control_door						},
	{	SL_SM_CHECKING_KEY_DOOR_REQ				,	SL_SM_CRITICAL			,	sl_sm_req_checking_key_door					},
	{	SL_SM_CHECKING_KEY_DOOR_RES				,	SL_SM_CRITICAL			,	sl_sm_res_checking_key_door					},
	{	SL_SM_MODBUS_BAUDRATE_SETTING_REQ		,	SL_SM_CRITICAL			,	sl_sm_modbus_baudrate_setting_req			},
};

tsm_t* tsm_sl_sm_table[] = {
	sl_sm_idle,
	sl_sm_auto_control,
	sl_sm_manual_control,
	sl_sm_setting,
	sl_sm_firmware_update,
	sl_sm_critical
};

uint8_t time_switch_air() {
	uint8_t ret = 0;
	return ret;
}

uint8_t process_case_air_cond(uint8_t total_aircond, uint8_t total_aircond_active) {
	uint8_t ret = 0;

	if (total_aircond == 2 && total_aircond_active == 1)		ret = 1;
	else if (total_aircond == 3 && total_aircond_active == 1)	ret = 1;
	else if (total_aircond == 3 && total_aircond_active == 2)	ret = 2;
	else if (total_aircond == 4 && total_aircond_active == 1)	ret = 1;
	else if (total_aircond == 4 && total_aircond_active == 2)	ret = 2;
	else if (total_aircond == 4 && total_aircond_active == 3)	ret = 3;

	return ret;
}

void process_priority_air_cond(uint8_t aircond_case) {
}

void process_status_air_cond(float temp, uint8_t sw) {
}

void process_status_fan_backup(float temp) {
}

void sl_sm_req_auto_control_output_power(ak_msg_t* msg) {
}

void sl_sm_req_output_power_status(ak_msg_t* msg) {
	/* request all output power status */
	output_power_ctrl_retry_time = 0;
}

void sl_sm_req_air_cond_status(ak_msg_t* msg) {
	/* request all air conditional status */
	output_power_ctrl_retry_time = 0;
}

void sl_sm_req_fan_status(ak_msg_t* msg) {
	/* request all air conditional status */
	output_power_ctrl_retry_time = 0;
}

void sl_sm_res_setting_ok(ak_msg_t* msg) {
	/* respone setting status ok */
}

void sl_sm_res_setting_busy(ak_msg_t* msg) {
}

void sl_sm_req_firmware_update_start(ak_msg_t* msg) {
}

void sl_sm_req_firmware_update_timeout(ak_msg_t* msg) {
}

void sl_sm_req_firmware_update_complete(ak_msg_t* msg) {
}

void sl_sm_req_firmware_update_error(ak_msg_t* msg) {
}

void sl_sm_create_output_power_status(ak_msg_t* msg) {
}

void sl_sm_create_air_cond_status(ak_msg_t* msg) {
}

void sl_sm_create_fan_status(ak_msg_t* msg) {
}

void sl_sm_req_sensor_modbus_slave_info(ak_msg_t* msg) {
}

void sl_sm_res_sensor_modbus_slave_info(ak_msg_t* msg) {
}

void sl_sm_res_control_auto_ok() {
	TSM_TRAN(&tsm_sl_sm, SL_SM_IDLE);
}

void sl_sm_res_control_auto_fail() {
	TSM_TRAN(&tsm_sl_sm, SL_SM_IDLE);
}

void sl_sm_req_tran_state(ak_msg_t* msg) {
}

void sl_mt_sm_res_control_mode(ak_msg_t* msg) {
}

void sl_sm_req_control_aircond(ak_msg_t* msg) {
}

void sl_sm_req_control_fan(ak_msg_t* msg) {
}

void sl_mt_sm_res_air_cond_manual_control() {
}

void sl_mt_sm_res_fan_manual_control() {
}

void sl_sm_req_checking_key_door(ak_msg_t* msg) {
}

void sl_sm_res_checking_key_door(ak_msg_t* msg) {
}

void sl_sm_req_control_door(ak_msg_t* msg) {
}

void sl_sm_res_control_door(ak_msg_t* msg) {
}

void sl_sm_req_manual_control_output_power(ak_msg_t* msg) {
}

void sl_sm_req_critical_control_output_power(ak_msg_t* msg) {
}

void sl_sm_modbus_baudrate_setting_req(ak_msg_t* msg) {
}
