/**
 ******************************************************************************
 * @author: ThanNT
 * @date:   13/08/2016
 ******************************************************************************
**/

#ifndef __TASK_SHELL_H__
#define __TASK_SHELL_H__

#include "../common/cmd_line.h"

#define SHELL_BUFFER_LENGHT				(32)

extern cmd_line_t lgn_cmd_table[];

#endif //__TASK_SHELL_H__
