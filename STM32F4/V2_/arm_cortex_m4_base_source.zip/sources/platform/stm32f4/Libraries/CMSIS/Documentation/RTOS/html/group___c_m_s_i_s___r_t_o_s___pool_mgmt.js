var group___c_m_s_i_s___r_t_o_s___pool_mgmt =
[
    [ "osFeature_Pool", "group___c_m_s_i_s___r_t_o_s___pool_mgmt.html#gadd84b683001de327894851b428587caa", null ],
    [ "osPool", "group___c_m_s_i_s___r_t_o_s___pool_mgmt.html#ga5f0b204a82327533d420210125c90697", null ],
    [ "osPoolDef", "group___c_m_s_i_s___r_t_o_s___pool_mgmt.html#ga87b471d4fe2d5dbd0040708edd52771b", null ],
    [ "osPoolAlloc", "group___c_m_s_i_s___r_t_o_s___pool_mgmt.html#gaa0b2994f1a866c19e0d11e6e0d44f543", null ],
    [ "osPoolCAlloc", "group___c_m_s_i_s___r_t_o_s___pool_mgmt.html#ga9f129fcad4730fbd1048ad4fa262f36a", null ],
    [ "osPoolCreate", "group___c_m_s_i_s___r_t_o_s___pool_mgmt.html#ga34af5c4f4ab38f4138ea7f1f9ece3a1a", null ],
    [ "osPoolFree", "group___c_m_s_i_s___r_t_o_s___pool_mgmt.html#ga4a861e9c469c9d0daf5721bf174f8e54", null ]
];