#ifndef __NRF_CONFIG_H__
#define __NRF_CONFIG_H__

#define MAX_NWK_MSG_LEN					1024

#define NRF_PHY_CHANEL_CFG				120

#endif // __NRF_CONFIG_H__
