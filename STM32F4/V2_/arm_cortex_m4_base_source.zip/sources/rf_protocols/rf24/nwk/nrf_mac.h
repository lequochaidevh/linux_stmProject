#ifndef __TASK_NRF_MAC_H__
#define __TASK_NRF_MAC_H__

#endif // __TASK_NRF_MAC_H__
