#ifndef __TASK_NRF_PHY_H__
#define __TASK_NRF_PHY_H__

#define MAX_PHY_PAYLOAD_LEN				32

extern void nrf_phy_switch_ptx_mode();
extern void nrf_phy_switch_prx_mode();

#endif // __TASK_NRF_PHY_H__
