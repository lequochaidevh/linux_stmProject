# ArduinoZigBee
# contact: thesiscommunity@gmail.com

Example Note: 

1. ArduinoZigBee/examples/ZigBeeGate/ZigBeeGate.ino

- Demo Gateway tích hơp các cảm biến Xiaomi zigbee (Door, PIR, Button, Temperature and Humidity, Ổ cắm)

![alt text](https://github.com/thesiscommunity/ArduinoZigBee/blob/master/images/ZigBeeGate.jpg)

2. ArduinoZigBee/examples/ZigBeeRouter/ZigBeeRouter.ino
- Demo 1 Node Router với các chức năng:
+ kích hoạt paring với ZigBeeGate (Coodinator).
+ gửi test data tới ZigBeeGate
