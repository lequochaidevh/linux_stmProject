#ifndef __APP_NON_CLEAR_RAM_H__
#define __APP_NON_CLEAR_RAM_H__

#include "app_data.h"

extern uint32_t sys_soft_reboot_counter;

#endif //__APP_NON_CLEAR_RAM_H__
