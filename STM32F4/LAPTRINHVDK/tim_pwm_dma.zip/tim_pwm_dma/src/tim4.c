#include "tim4.h"

uint16_t u16Buff[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};

void tim4_init(void)
{
	
	/* tim base */
	RCC->APB1ENR |= (1 << 2);
	TIM4->CR1 = (1 << 7) | (1 << 1);
	TIM4->PSC = 84 - 1;
	TIM4->ARR = 10 - 1;
	TIM4->CR1 &= ~(1 << 1);
	TIM4->EGR = 1;
	TIM4->CR1 |= (1 << 0);
	
	/* PWM */
	TIM4->CCMR1 &= ~(7 << 4);
	TIM4->CCMR1 |= (6 << 4);
	//TIM4->CCMR1 |= (1 << 3);
	TIM4->CCER |= (1 << 0);
	TIM4->CCR1 = 3;
	
	/* PB6 */
	RCC->AHB1ENR |= (1 << 1);
	GPIOB->MODER &= ~(3 << 12);
	GPIOB->MODER |= (1 << 13);
	GPIOB->OSPEEDR |= (3 << 12);
	GPIOB->AFR[0] &= ~(15 << 24);
	GPIOB->AFR[0] |= (2 << 24);

#if 0
	/* DMA */
	RCC->AHB1ENR |= (1 << 21);
	DMA1_Stream0->CR |= (2 << 25);
	DMA1_Stream0->CR |= (1 << 13);
	DMA1_Stream0->CR |= (1 << 11);
	DMA1_Stream0->CR |= (1 << 10);
	DMA1_Stream0->CR |= (1 << 8);
	DMA1_Stream0->CR |= (1 << 6);
	
	DMA1_Stream0->NDTR = 9;
	DMA1_Stream0->PAR = (uint32_t)(&TIM4->CCR1);
	DMA1_Stream0->M0AR = (uint32_t)u16Buff;
	
	/* dma enable */
	DMA1_Stream0->CR |= (1 << 0);
	
	TIM4->DIER |= (1 << 9);
#endif
}
