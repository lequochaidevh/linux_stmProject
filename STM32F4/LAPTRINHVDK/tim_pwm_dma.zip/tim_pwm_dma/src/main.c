#include "stm32f4xx.h"                  // Device header
#include "tim4.h"

void delay_ms(uint32_t u32DelayInMs);

void delay_ms(uint32_t u32DelayInMs)
{
	
	while (u32DelayInMs) {
		/*
		TIM6->CNT = 0;
		while (TIM6->CNT < 1000) {
		}
		*/
		TIM_SetCounter(TIM6, 0);
		while (TIM_GetCounter(TIM6) < 1000) {
		}
		--u32DelayInMs;
	}
}

int main(void)
{	
	GPIO_InitTypeDef gpioInit;
	TIM_TimeBaseInitTypeDef timInit;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	
	gpioInit.GPIO_Mode = GPIO_Mode_OUT;
	gpioInit.GPIO_OType = GPIO_OType_PP;
	gpioInit.GPIO_Pin = GPIO_Pin_12;
	gpioInit.GPIO_PuPd = GPIO_PuPd_NOPULL;
	gpioInit.GPIO_Speed = GPIO_High_Speed;
	
	GPIO_Init(GPIOD, &gpioInit);
	
	/*
	RCC->APB1ENR |= (1 << 4);
	TIM6->CR1 |= (1 << 1);
	TIM6->PSC = (84 - 1);
	TIM6->CR1 &= ~(1 << 1);
	TIM6->EGR = 1;
	TIM6->CR1 |= (1 << 0);
	*/
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	timInit.TIM_Prescaler = 84 - 1;
	timInit.TIM_Period = 0xFFFF;
	TIM_TimeBaseInit(TIM6, &timInit);
	TIM_Cmd(TIM6, ENABLE);
	
	tim4_init();
	
	while (1) {
		GPIO_SetBits(GPIOD, GPIO_Pin_12);
		TIM4->CCR1 = 1;
		delay_ms(1);
		GPIO_ResetBits(GPIOD, GPIO_Pin_12);
		TIM4->CCR1 = 2;
		delay_ms(1);
	}
}
