#ifndef TIM4_H_
#define TIM4_H_

#include "stm32f4xx.h"

void tim4_init(void);

#endif
